import { BrowserRouter as Router, Route, Routes, Navigate, Outlet } from "react-router-dom";
import { Suspense } from "react";
import Dashboard from "../pages/dashboard-page/dashboard";
import Header from "../layouts/header/header";
import Country from "../pages/Master/Country/Country";
import State from "../pages/Master/State/State";
import Adminuserrights from "../pages/Adminuserrights/Adminuserrights";
import AdminUser from "../pages/Master/Adminuser/adminuser";
import AddEmp from "../pages/Master/Adminuser/addemp";
import Viewnew from "../pages/View/Viewnew";
import Insert from "../pages/View/Insert";
import ChangePassword from "../pages/change-password/changepassword";
import Notification from '../pages/san_search/Notification/Notification';
import Search from "../pages/san_search/Search";
import BulkData from "../pages/san_search/Bulk/BulkData";
import ScreeningDetails from "../pages/screeningDetails/screeningDetails";
import SanTaskAssign from "../pages/san_search/Bulk/SanTaskAssign";
import BulkUpload from "../pages/san_search/Bulk/BulkUpload";
import FlowLevel from "../pages/san_search/level search/FlowLevel";
import LevelFlowSearch from "../pages/san_search/level search/LevelFlowSearch";
import Loader from "../pages/loader/loader";
import UiTestingCountry from "../pages/san_search/UiTestingCountry";
import UiTestingName from "../pages/san_search/UiTestingName";
import TwoPartRecords from "../pages/san_search/UiTestingTwoPartRecords";
import SanReport from "../pages/san_search/SanReport";
import SanReopen from "../pages/san_search/SanReopen";
import SanReportMonth from "../pages/san_search/SanReportMonth";
import STRfile from "../pages/san_search/STRfile";
import Login from "../pages/Login/login";
import TimeReport from "../pages/san_search/TimeReport";
import XmlUploader from "../pages/san_search/XmlUploader";
import SanctionSearch from "../pages/Insert/ReportSearch";
import UnSearchTesing from "../pages/san_search/UnSearchTesing";
import UiReciveSingleRecord from "../pages/san_search/UiReciveSingleRecord";

const AppRouter = () => {

    const isAuthenticated = () => {
        const loginDetails = sessionStorage.getItem('loginDetails') || localStorage.getItem('loginDetails');
        return loginDetails !== null;
    };

    return (
        <Suspense fallback={<span>Loading....</span>}>
            <>
                <Router >
                    <Routes>
                        <Route path="/login" element={<Login />} />
                        <Route path="/" element={isAuthenticated() ? (<Outlet />) : (<Navigate to="/login" />)} />
                        {/* Unprotected Route */}

                        {/* Nested routes */}
                        <Route path="/" element={<Outlet />}>
                            <Route path="/dashboard" element={<Dashboard />} />
                            <Route path="/header" element={<Header />} />
                            <Route path="/Country" element={<Country />} />
                            <Route path="/State" element={<State />} />
                            <Route path="/adminuser" element={<AdminUser />} />
                            <Route path="/addemp" element={<AddEmp />} />
                            <Route path="/Adminuserrights" element={<Adminuserrights />} />
                            <Route path="/ChangePassword" element={<ChangePassword />} />
                            <Route path="/Viewnew" element={<Viewnew />} />
                            <Route path="/Insert" element={<Insert />} />
                            <Route path="/Search" element={<Search />} />
                            <Route path="/uiTestingcountry" element={<UiTestingCountry />} />
                            <Route path="/uiTestingtwopartrecords" element={<TwoPartRecords />} />
                            <Route path="/Insert" element={<Insert />} />
                            <Route path="/Search" element={<Search />} />
                            <Route path="/ScreeningDetails" element={<ScreeningDetails />} />
                            <Route path="/BulkData" element={<BulkData />} />
                            <Route path="/SanTaskAssign" element={<SanTaskAssign />} />
                            <Route path="/BulkUpload" element={<BulkUpload />} />

                            {/* san */}
                            <Route path="/FlowLevel" element={<FlowLevel />} />
                            <Route path="/LevelFlowSearch" element={<LevelFlowSearch />} />
                            <Route path="/SanctionSearch" element={<SanctionSearch />} />
                            <Route path="/FirstLevelPending" element={<Notification />} />
                            <Route path="/Loader" element={<Loader />} />
                            <Route path="/uiTestingname" element={<UiTestingName />} />
                            <Route path="/SanReport" element={<SanReport />} />
                            <Route path="/SanReopen" element={<SanReopen />} />
                            <Route path="/SanReportMonth" element={<SanReportMonth />} />
                            <Route path="/STRfile" element={<STRfile />} />
                            <Route path="/timeReport" element={<TimeReport />} />
                            <Route path="/XmlUploader" element={<XmlUploader />} />
                            <Route path="/UnSearchTesing" element={<UnSearchTesing />} />
                            <Route path="/UiReciveSingleRecord" element={<UiReciveSingleRecord />} />
                        </Route>
                    </Routes>
                </Router>
            </>
        </Suspense>
    );
};

export default AppRouter;