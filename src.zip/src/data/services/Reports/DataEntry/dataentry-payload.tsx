export interface DataEntryData {
  frmDate: string;
  toDate: string;
  name: string;
  count: string;
}