import HttpClientWrapper from '../../../api/http-client-wrapper';


class TimeReportService {

    private httpClientWrapper: HttpClientWrapper;

    constructor() {
        this.httpClientWrapper = new HttpClientWrapper();
    }

    getTimeReportData = async (levelId: string, statusId: string, uid: string,startTime:string,endTime:string): Promise<any[]> => {
        try {
            const response = await this.httpClientWrapper.get(
                `/api/v1/TimeReport?levelId=${levelId}&statusId=${statusId}&uid=${uid}&startDate=${encodeURIComponent(startTime)}&endDate=${encodeURIComponent(endTime)}`
              );
            console.log('Time Report Response:', response);
            return response;
        } catch (error) {
            console.error('Error fetching time report data:', error);
            throw error;
        }
    };


}

export default TimeReportService;