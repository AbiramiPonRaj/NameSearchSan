export interface TimeReportData {
    searchedName: string,
    searchInsertedTime:string,
    searchInsertedSeconds:number,
    totalRelatedRecords:number,
    allHitRecordInsertedTimes:string,
    closedCaseName:string,
    caseClosedTime:string,
    caseClosedSeconds:number,
    timeToCloseSeconds:number,
    closedLevelId:number,
    escalatedCaseName:string,
    escalationTime:string,
    escalationSeconds:number,
    timeToEscalationSeconds:number,
    escalatedLevelId:number,

}
