import HttpClientWrapper from "../../../api/http-client-wrapper";
import { format } from 'date-fns';
class SanAlertApiService {

    private httpClientWrapper: HttpClientWrapper;

    constructor() {
        this.httpClientWrapper = new HttpClientWrapper();
    }

    getUsers = async () => {
        try {
            const response = await this.httpClientWrapper.get('/api/v1/users');
            return response;
        } catch (error) {
            console.error('Error fetching the getUsers:', error);
            throw error;
        }
    };

    getStatus = async () => {
        try {
            const response = await this.httpClientWrapper.get('/api/v1/Status');
            return response;
        } catch (error) {
            console.error('Error fetching the getStatus:', error);
            throw error;
        }
    };
     
    async getSanAlertReport(uid: any[], statusId: any[], startDate: Date, endDate: Date) {
        try {
            // Format dates to 'yyyy-MM-dd' format
            const formattedStartDate = format(startDate, 'yyyy-MM-dd');
            const formattedEndDate = format(endDate, 'yyyy-MM-dd');
    
            // Convert uid and statusId arrays to comma-separated strings
            const uidString = uid.join(',');
            const statusIdString = statusId.join(',');
    
            // Correct URL with required parameters
            const response = await this.httpClientWrapper.get(`/api/v1/SanAlertReport?uid=${uidString}&statusId=${statusIdString}&startDate=${formattedStartDate}&endDate=${formattedEndDate}`);
    
            console.log('API Response:', response);
            return response;
        } catch (error: any) {
            if (error.response) {
                console.error('Request failed with status code:', error.response.status);
                console.error('Response data:', error.response.data);
            } else if (error.request) {
                console.error('No response received. Request made but no response.');
            } else {
                console.error('Error setting up the request:', error.message);
            }
            throw new Error(`Error in API request: ${error}`);
        }
    }
    async getSanAlertReportMonth(
        uid: any[], 
        statusId: any[], 
        startMonth: string, 
        startYear: string, 
        endMonth: string, 

        endYear: string
    ) {  
        try {
    
            const uidString = uid.join(',');
            const statusIdString = statusId.join(',');
    
            // Construct API URL with corrected query parameters
            const url = `/api/v1/SanAlertReport/results?uid=${uidString}&statusId=${statusIdString}&startMonth=${startMonth}&endMonth=${endMonth}&startYear=${startYear}&endYear=${endYear}`;
    
            // Make API request
            const response = await this.httpClientWrapper.get(url);
    
            console.log('API Response:', response);
            return response;
        } catch (error: any) {
            if (error.response) {
                console.error('Request failed with status code:', error.response.status);
                console.error('Response data:', error.response.data);
            } else if (error.request) {
                console.error('No response received. Request made but no response.');
            } else {
                console.error('Error setting up the request:', error.message);
            }
            throw new Error(`Error in API request: ${error}`);
        }
    }
    
    // async getSanAlertReportMonth(uid: any[], statusId: any[], month: string, year: string) { 
    //     try {
    //         // Convert uid and statusId arrays to comma-separated strings
    //         const uidString = uid.join(',');
    //         const statusIdString = statusId.join(',');
    
    //         // Ensure month is always two-digit (e.g., '01' for January)
    //         const formattedMonth = month.padStart(2, '0'); 
    
    //         // Ensure year is a valid four-digit string
    //         const formattedYear = year.toString();
    
    //         // Correct URL with fixed parameters
    //         const response = await this.httpClientWrapper.get(
    //             `/api/v1/SanAlertReport/results?uid=${uidString}&statusId=${statusIdString}&month=${formattedMonth}&year=${formattedYear}`
    //         );
    
    //         console.log('API Response:', response);
    //         return response;
    //     } catch (error: any) {
    //         if (error.response) {
    //             console.error('Request failed with status code:', error.response.status);
    //             console.error('Response data:', error.response.data);
    //         } else if (error.request) {
    //             console.error('No response received. Request made but no response.');
    //         } else {
    //             console.error('Error setting up the request:', error.message);
    //         }
    //         throw new Error(`Error in API request: ${error}`);
    //     }
    // }
    
    // async getReopen(uid: string) {
    //     try {
    //       const response = await this.httpClientWrapper.get(`/api/v1/SanReopen?uid=${uid}`);
    //       console.log("Fetched Reopen Cases:", response);
    //       return response;
    //     } catch (error) {
    //       console.error("Error fetching reopen cases:", error);
    //       throw error;
    //     }
    // }
    // async getReopen(uid: any,  startDate: Date, endDate: Date) {
    //     try {
    //         // Format dates to 'yyyy-MM-dd' format
    //         const formattedStartDate = format(startDate, 'yyyy-MM-dd');
    //         const formattedEndDate = format(endDate, 'yyyy-MM-dd');
    
    //         // Convert uid and statusId arrays to comma-separated strings
    //         const uidString = uid;
        
    
    //         // Correct URL with required parameters
    //         const response = await this.httpClientWrapper.get(`/api/v1/SanReopen?uid=${uidString}&startDate=${formattedStartDate}&endDate=${formattedEndDate}`);
    
    //         console.log('API Response:', response);
    //         return response;
    //     } catch (error: any) {
    //         if (error.response) {
    //             console.error('Request failed with status code:', error.response.status);
    //             console.error('Response data:', error.response.data);
    //         } else if (error.request) {
    //             console.error('No response received. Request made but no response.');
    //         } else {
    //             console.error('Error setting up the request:', error.message);
    //         }
    //         throw new Error(`Error in API request: ${error}`);
    //     }
    // }
    async  getReopen(uid: any, startDate?: Date, endDate?: Date) {
        try {
            if (!uid) {
                throw new Error('UID is required.');
            }
    
            // Construct query parameters dynamically
            const queryParams = new URLSearchParams({ uid: uid.toString() });
    
            if (startDate) queryParams.append('startDate', format(startDate, 'yyyy-MM-dd'));
            if (endDate) queryParams.append('endDate', format(endDate, 'yyyy-MM-dd'));
    
            // Make API request
            const response = await this.httpClientWrapper.get(`/api/v1/SanReopen?${queryParams.toString()}`);
    
            console.log('API Response:', response);
            return response;
        } catch (error: any) {
            console.error('API Request Failed:', error);
            throw new Error(`Error fetching SanReopen data: ${error.message}`);
        }
    }

    // getSTRfile = async () => {
    //     try {
    //         const response = await this.httpClientWrapper.get('/api/v1/SanSTRfile/fetch-all');
    //         return response;
    //     } catch (error) {
    //         console.error('Error fetching the getStatus:', error);
    //         throw error;
    //     }
    // };
     
    async getSTRfile( startDate: Date, endDate: Date) {
        try {
            // Format dates to 'yyyy-MM-dd' format
            const formattedStartDate = format(startDate, 'yyyy-MM-dd');
            const formattedEndDate = format(endDate, 'yyyy-MM-dd');
    

    
            // Correct URL with required parameters
            const response = await this.httpClientWrapper.get(`/api/v1/SanSTRfile/fetch-all?startDate=${formattedStartDate}&endDate=${formattedEndDate}`);
    
            console.log('API Response:', response);
            return response;
        } catch (error: any) {
            if (error.response) {
                console.error('Request failed with status code:', error.response.status);
                console.error('Response data:', error.response.data);
            } else if (error.request) {
                console.error('No response received. Request made but no response.');
            } else {
                console.error('Error setting up the request:', error.message);
            }
            throw new Error(`Error in API request: ${error}`);
        }
    }

}

export default SanAlertApiService;