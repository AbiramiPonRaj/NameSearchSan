export interface Status {
    id: number;
    name: string;
    status: boolean;
}

export interface Users {
    id: number;
    userName: string;
}