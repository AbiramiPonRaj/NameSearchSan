export interface UiReciveSingleRecord {
    name: string;
    dob: string;
    id: string;
    country: string;
    entityType: number;
    score: number;
}

export interface SanctionsAlSearch {
    sessionID: number;
    uid: string;
    sourceName: string;
    maxWeightageScore: number;
    algorithm1WeightageScore: number;
    algorithm2WeightageScore: number;
    algorithm3WeightageScore: number;
    algorithm4WeightageScore: number;
    algorithm5WeightageScore: number;
    matchedName: string;
}