import HttpClientWrapper from "../../../api/http-client-wrapper";

class UiReciveSingleRecordService {

    private httpClientWrapper: HttpClientWrapper;

    constructor() {
        this.httpClientWrapper = new HttpClientWrapper();
    }

    getUiReciveSingleRecord = async (name: string, dob: string, id: string, country: string, entityType: number, score: string) => {
        try {
            const response = await this.httpClientWrapper.get(`/api/v1/UiReciveSingleRecordApiResources/SanctionsAlSearch?name=${name}&dob=${dob}&id=${id}country=${country}&entityType=${entityType}&score=${score}`);
            return response;
        } catch (error) {
            console.error(`Error fetching the getUiReciveSingleRecord:`, error);
            throw error;
        }
    };

}

export default UiReciveSingleRecordService;