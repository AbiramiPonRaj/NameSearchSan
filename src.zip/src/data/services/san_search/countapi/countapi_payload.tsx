export interface SearchDTO {
    name: string;
    dob: string;
    id: string;
    country: string;
    entityType: number;
    score: number;
  }
  
  
  export interface SanSearchAlgorithmResult {
    persion_id: number;
    onsideMultiPara: number[];
    name: string;
    dob: string;
    id: string;
    country: string;
  }