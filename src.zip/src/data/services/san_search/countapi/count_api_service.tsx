import HttpClientWrapper from "../../../api/http-client-wrapper";
import { SanSearchAlgorithmResult, SearchDTO } from "./countapi_payload";

class CountApiService {
  private httpClientWrapper: HttpClientWrapper;

  constructor() {
    this.httpClientWrapper = new HttpClientWrapper();
  }

  getCountApiResources = async (
    searchDTO: SearchDTO
  ): Promise<SanSearchAlgorithmResult[]> => {
    try {
      const response = await this.httpClientWrapper.get(
        `/api/v1/urlInterFace/fetch-UkSearchSanctionedPersons?name=${searchDTO.name}&dob=${searchDTO.dob}&country=${searchDTO.country}&id=${searchDTO.id}&score=${searchDTO.score}&entityType=${searchDTO.entityType}`
      );
      return response;
    } catch (error) {
      throw error;
    }
  };

  getUkSearchSanctioned = async (searchDTO: SearchDTO): Promise<SanSearchAlgorithmResult[]> => {
    try {
      const response = await this.httpClientWrapper.post(
        "/api/v1/urlInterFace/fetch-UkSearchSanctionedPersons",
        {
          name: searchDTO.name,
          dob: searchDTO.dob,
          id: searchDTO.id,
          country: searchDTO.country,
          entityType: searchDTO.entityType,
          score: searchDTO.score
        }
      );
      return response;
    } catch (error) {
      throw error;
    }
  };
  getUnSearchSanctioned = async (searchDTO: SearchDTO, fileType: number): Promise<SanSearchAlgorithmResult[]> => {
    try {
      const response = await this.httpClientWrapper.post(
        `/api/v1/urlInterFace/fetch-SearchSanctionedPersons?fileType=${fileType}`, // Include fileType here
        {
          name: searchDTO.name,
          dob: searchDTO.dob,
          id: searchDTO.id,
          country: searchDTO.country,
          entityType: searchDTO.entityType,
          score: searchDTO.score
        }
      );
      return response;
    } catch (error) {
      throw error;
    }
  };

}

export default CountApiService;
