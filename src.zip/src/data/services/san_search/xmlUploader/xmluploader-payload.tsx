export interface xmlUploaderPayload {
    id: number;
    fileName: string;
    fileSize: number;
    recordCount: number;
    processingTime: number;
    fileType: string;
    createdAt: string;
    userName: string;
}

export interface fileTypePayload {
    id: number;
    name: string;
    valid: boolean;
    uid: number;
    euid: number;
    createdAt: string;
    updatedAt: string;
    status: string;
}