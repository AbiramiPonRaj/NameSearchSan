interface AssociatedlistPayload {
    id: number;
    name: string
  }
export default AssociatedlistPayload;