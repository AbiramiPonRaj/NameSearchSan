interface OtherAssociationRequest {
    otherAssociationAsPerMedia: string,
  
  }
export default OtherAssociationRequest;