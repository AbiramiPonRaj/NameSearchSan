interface ContactDTO {
    pepId: number;
    associatedCompaniesId: number;
    emailID: string;
  }
  export default ContactDTO;