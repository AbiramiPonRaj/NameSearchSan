interface PartyRequest {
    formerAndCurrent: String,
    stateId: string,
    countryId: string,
    otherInformation: string,
    Died: string,
    Permanent_Address: string,
    partyMasterId:number;
  }
  export default PartyRequest;