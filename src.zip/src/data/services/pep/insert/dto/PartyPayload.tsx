interface PartyPayload {
  
    partyName: string
  }
export default PartyPayload;