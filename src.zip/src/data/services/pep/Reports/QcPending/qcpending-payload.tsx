export interface QcPendingData {
    frmDate: string;
      toDate: string;
      count: string;
  }