export interface Bank {
    name: string;
    id: number;
}

export interface TableData {
    description: string;
    application: number;
}