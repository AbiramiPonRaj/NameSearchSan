export interface CustomerEditData {
  frmDate: string;
  toDate: string;
  targetCustomerName: string;
  count: string;
  username: string;
  created_at: string;
  ticketId: string;
  complaintId: number,
  uid: number,
  
}

export interface CustomerEditDatas {
  frmDate: string;
  toDate: string;
  targetCustomerName: string;
 
  username: string;
  created_at: string;
  ticketId: number;
  
  uid: number,
  fraudId:number

  
}
