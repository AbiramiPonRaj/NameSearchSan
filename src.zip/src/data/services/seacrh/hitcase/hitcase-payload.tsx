export interface HitcasePayload {
 // id:string;
  display: string;
  searchId: string;
  hitId: string;
  criminalId: string;
  levelId: string;
  statusNowId: string;
  cycleId: string;
  uid:string;
  remark: string;
//  valid:string;

}