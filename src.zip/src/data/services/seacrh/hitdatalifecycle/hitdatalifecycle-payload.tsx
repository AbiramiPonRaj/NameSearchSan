//Hitdatalifecycle Payload
export interface HitdatalifecyclePayload {
  searchId: string;
  hitId: string;
  criminalId: string;
  caseId: string;
  levelId: string;
  statusId: string;
  uid: string;
  remark: string;
}
