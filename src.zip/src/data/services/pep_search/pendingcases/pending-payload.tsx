export interface PindingcasesPayload {
  caseId: string;
  criminalId: string;
  hitId: string;
  levelId: string;
  searchId: string;
  statusId: string;
  matchingScore: string;
  remark: string; 
  uid:string;
  criminalName:string;
};