interface RelativeRequest {
  relativeMasterId: String,
  relativeName: String,
  pan: String
}

export default RelativeRequest;