interface RelativeChildrenDTO {
  pepId: number;
  relativeDetId: number;
  childrenName: string;
  pan: string;
}

export default RelativeChildrenDTO;