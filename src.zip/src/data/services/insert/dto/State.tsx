interface State {
  id: string;
  countryId: string;
  stateName: string;
}

export default State;