interface CustomerRequest {
  name: string;
  sourceLink: string;
  education: string;
  dob: string;
  pan: string;
  directorsIdentificationNumber: string;
}

export default CustomerRequest;