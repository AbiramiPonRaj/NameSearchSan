interface AkaDetRequest {
  akaName: string;
}
export default AkaDetRequest;