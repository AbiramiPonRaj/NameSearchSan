interface AddressDTO {
  id: number;
  pepId: number;
  associatedCompaniesId: number;
  registeredAddress: string;
  listOfDirectors: string;
}

export default AddressDTO;