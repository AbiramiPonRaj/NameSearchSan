export interface RelativePayload {
  name: string;
}