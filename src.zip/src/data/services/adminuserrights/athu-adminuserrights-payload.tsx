export interface AdminUserRightsPayload {
    id: string;
    modId: string;
    entUid: string;
    modDetId: string;
    valid: string;
    userName: string;
}