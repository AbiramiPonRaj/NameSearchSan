import React, { useEffect, useRef, useState } from "react";
import { Box, Button, Card, Container, Dialog, DialogActions, DialogContent, DialogTitle, Grid, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import Header from "../../layouts/header/header";
import { useSelector } from "react-redux";
import { fileTypePayload, xmlUploaderPayload } from "../../data/services/san_search/xmlUploader/xmluploader-payload";
import XmlUploaderService from "../../data/services/san_search/xmlUploader/xmluploader-api-service";
import ClearIcon from "@mui/icons-material/Clear";
import Papa from "papaparse";
import Loader from "../loader/loader";

const XMLUploader: React.FC = () => {

    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [open, setOpen] = useState(false);
    const userDetails = useSelector((state: any) => state.loginReducer);
    const uid = userDetails.loginDetails.id;
    const [uploadStatus, setUploadStatus] = useState<string>("");
    const [uploadType, setUploadType] = useState<string>("0");
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const [csvData, setCsvData] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);

    const [xmlFiles, setxmlfiles] = useState<xmlUploaderPayload[]>([]);
    const [fileType, setFileType] = useState<fileTypePayload[]>([]);
    const xmlUploaderService = new XmlUploaderService();

    useEffect(() => {
        fetchAllData();
    }, []);

    const fetchAllData = async () => {
        try {
            const [xmlfiles, fileType] = await Promise.all([
                xmlUploaderService.getXmlFiles(),
                xmlUploaderService.getFileType()
            ]);
            const sortedXmlFiles = xmlfiles.sort((a: { createdAt: string | number | Date; }, b: { createdAt: string | number | Date; }) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setxmlfiles(sortedXmlFiles);
            setFileType(fileType);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files.length > 0) {
            setSelectedFile(event.target.files[0]);
            setUploadStatus("");
        }
    };

    const handleUpload = async () => {
        if (!selectedFile) {
            setUploadStatus("Please select a file before uploading.");
            return;
        }
        setLoading(true);
        const formData = new FormData();
        formData.append("xmlFile", selectedFile);
        formData.append("uid", uid);
        formData.append("pathId", uploadType);
        try {
            const response = await xmlUploaderService.saveXmlFiles(formData);
            console.log(`Upload successful`, response);
            setUploadStatus("Upload successful!");
            setSelectedFile(null);
            setUploadType("0");
            if (fileInputRef.current) {
                fileInputRef.current.value = "";
            }
            fetchAllData();
            setTimeout(() => {
                setUploadStatus("");
            }, 3000);
        } catch (error: any) {
            console.error("Error:", error);
            const errorMessage =
                error?.response?.data ||
                error?.message ||
                "Upload failed. Please try again.";
            setUploadStatus(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    const getAcceptType = (uploadType: string | number) => {
        if (uploadType === 1 || uploadType === 2 || uploadType === 3 || uploadType === 4) return ".csv";
        return "";
    };

    const handleFileClick = async (id: number) => {
        try {
            setLoading(true);
            const response = await xmlUploaderService.getXmlfileName(id);
            const csvContent = response;
            Papa.parse(csvContent, {
                complete: (result: { data: React.SetStateAction<any[]>; }) => {
                    setCsvData(result.data);
                },
                header: true,
            });
            setOpen(true);
        } catch (error) {
            console.error("Error fetching file content:", error);
        } finally {
            setLoading(false);
        }
    };

    const renderCsvTable = () => {
        if (csvData.length === 0) return <p>No data available</p>;

        const headers = Object.keys(csvData[0]);

        return (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                    <tr>
                        {headers.map((header) => (
                            <th key={header} style={{ padding: "8px", border: "1px solid #ddd" }}>
                                {header}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {csvData.map((row: { [x: string]: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | null | undefined; }, index: React.Key | null | undefined) => (
                        <tr key={index}>
                            {headers.map((header) => (
                                <td key={header} style={{ padding: "8px", border: "1px solid #ddd" }}>
                                    {row[header]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        );
    };

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Header />
                <Box component="main" sx={{ flexGrow: 1, mt: 4 }}>
                    <Container maxWidth="lg" style={{ marginTop: '2%', maxWidth: '100%' }}>
                        <Typography variant="h5" fontWeight="bold" textAlign="center" gutterBottom>
                            XML/CSV File Uploader
                        </Typography>
                        <Grid container spacing={2} justifyContent="left">
                            <Card sx={{ width: '99%', padding: 2, boxShadow: 3, marginLeft: '1%', marginTop: '3%' }}>
                                <Grid container spacing={2}>
                                    <Grid item xs={4}>
                                        <Box display="flex" alignItems="center">
                                            <Select
                                                fullWidth
                                                value={uploadType}
                                                onChange={(e) => setUploadType(e.target.value)}
                                                variant="outlined"
                                                size="small"
                                                displayEmpty
                                            >
                                                <MenuItem value={0} disabled>Select an option</MenuItem>
                                                {fileType.map((item) => (
                                                    <MenuItem key={item.id} value={item.id}>
                                                        {item.name}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                            {uploadType !== "0" && (
                                                <ClearIcon
                                                    onClick={() => setUploadType("0")}
                                                    sx={{ ml: 1, cursor: 'pointer', color: '#888' }}
                                                />
                                            )}
                                        </Box>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <input
                                            ref={fileInputRef}
                                            type="file"
                                            accept={getAcceptType(Number(uploadType))}
                                            onChange={handleFileChange}
                                            style={{ display: "none" }}
                                            id="file-input"
                                            disabled={uploadType === "0"}
                                        />
                                        <label htmlFor="file-input">
                                            <Button variant="outlined" component="span" disabled={uploadType === "0"}>
                                                Choose File
                                            </Button>
                                            <span style={{ marginLeft: "10px", fontSize: "12px", color: "#333" }}>
                                                {selectedFile?.name || "No file chosen"}
                                            </span>
                                        </label>
                                    </Grid>
                                    <Grid item xs={2}>
                                        <Button
                                            fullWidth
                                            variant="contained"
                                            color="primary"
                                            onClick={handleUpload}
                                        >
                                            Upload
                                        </Button>
                                    </Grid>
                                    {uploadStatus && (
                                        <Grid item xs={2}>
                                            <Typography
                                                color={
                                                    uploadStatus.toLowerCase().includes("failed") ||
                                                        uploadStatus.toLowerCase().includes("please") ||
                                                        uploadStatus.toLowerCase().includes("already")
                                                        ? "error"
                                                        : "success.main"
                                                }
                                            >
                                                {uploadStatus}
                                            </Typography>
                                        </Grid>
                                    )}
                                </Grid>
                            </Card>
                        </Grid>
                    </Container>
                    <TableContainer component={Paper} style={{ width: '98%', overflowX: 'auto', marginLeft: '1%', marginTop: '1%' }} sx={{ maxHeight: { xs: "300px", md: "300px", lg: "350px", xl: "800px" } }}>
                        <Table size="small" stickyHeader aria-label="sticky table" style={{ margin: '0 auto' }}>
                            <TableHead sx={{ backgroundColor: '#cccdd1' }}>
                                <TableRow className="tableHeading">
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>S.No</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>User Name</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>File Type</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>File Name</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>Size (KB)</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>Processing Time (sec)</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>Record Count</strong></TableCell>
                                    <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}><strong>Created At (yy-mm-dd)</strong></TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {xmlFiles.length > 0 ? (
                                    xmlFiles.map((file, index) => (
                                        <TableRow key={file.id}>
                                            <TableCell>{index + 1}</TableCell>
                                            <TableCell>{file.userName || 'N/A'} </TableCell>
                                            <TableCell>{file.fileType || 'N/A'} </TableCell>
                                            <TableCell>
                                                <Button onClick={() => handleFileClick(file.id)} color="primary">
                                                    {file.fileName || 'N/A'}
                                                </Button>
                                            </TableCell>
                                            <TableCell>{(file.fileSize / 1024).toFixed(2) || 'N/A'}</TableCell>
                                            <TableCell>{file.processingTime}</TableCell>
                                            <TableCell>{file.recordCount || 'N/A'}</TableCell>
                                            <TableCell>{file.createdAt || 'N/A'}</TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={7} align="center">
                                            No files found.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    {loading && <Loader />}
                    <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="lg">
                        <DialogTitle>File Content</DialogTitle>
                        <DialogContent>
                            {renderCsvTable()}
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={() => setOpen(false)} color="primary">
                                Close
                            </Button>
                        </DialogActions>
                    </Dialog>
                </Box>
            </Box>
        </>
    );
};

export default XMLUploader;