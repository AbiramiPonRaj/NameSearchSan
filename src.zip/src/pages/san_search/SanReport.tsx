import React, { useState, useEffect } from "react";
import {
  Box,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  Chip,
  TextField,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  Paper,
  TableCell,
  TableBody,
  Card,
  IconButton,
  Grid,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import LevelStatusMappingApiService from "../../data/services/san_search/levelstatusmapping/levelstatusmapping-api-service";
import SearchApiService from "../../data/services/san_search/search-api-service";
import { useSelector } from "react-redux";
import Header from "../../layouts/header/header";
import SanAlertApiService from '../../data/services/san_search/sanAlert/sanAlert-api-service';
import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import saveAs from "file-saver";
import { Download, PictureAsPdf, TableChart } from "@mui/icons-material";
import { FaFileExcel, FaFileCsv, FaFilePdf } from "react-icons/fa";


interface Status {
  id: number;
  name: string;

}

interface User {
  id: string;
  userName: string;
}
interface AlertReport {
  name: string;
  searchName: string;
  searchId: number;
  hitId: number;
  criminalId: number;
  criminalName: string;
  matchingScore: number;
  remark: string;
  caseId: number;
  fileType: number;
  uid: number;
  created_at: string;
  currentStatus: string

}

function SanReport() {
  const [users, setUsers] = useState<User[]>([]);
  const [statuses, setStatuses] = useState<Status[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<number[]>([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [alertReports, setAlertReports] = useState<AlertReport[]>([]);

  const userDetails = useSelector((state: any) => state.loginReducer);
  const loginDetails = userDetails.loginDetails;
  const levelService = new LevelStatusMappingApiService();
  const searchApi = new SearchApiService();
  const sanAlertServices = new SanAlertApiService();
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersResponse, statusesResponse] = await Promise.all([
          searchApi.getSanUser(),
          sanAlertServices.getStatus(),
        ]);
        setUsers(usersResponse);
        setStatuses(statusesResponse);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [loginDetails]);

  // Handle User Selection
  const handleUserChange = (event: any) => {
    setSelectedUserIds(event.target.value);
  };

  // Handle Status Selection
  const handleStatusChange = (event: any) => {
    setSelectedStatuses(event.target.value);
  };

  // Handle User Deletion
  const handleUserDelete = (id: string) => {
    setSelectedUserIds((prev) => prev.filter((userId) => userId !== id));
  };

  // Handle Status Deletion
  const handleStatusDelete = (id: number) => {
    setSelectedStatuses((prev) => prev.filter((statusId) => statusId !== id));
  };

  const handleSubmit = async () => {
    if (selectedUserIds.length === 0 || selectedStatuses.length === 0 || !fromDate || !toDate) {
      alert("Please select users, statuses, and date range.");
      return;
    }

    try {
      // Pass the entire arrays instead of just the first element
      const response = await sanAlertServices.getSanAlertReport(
        selectedUserIds,  // Pass the entire array
        selectedStatuses,  // Pass the entire array
        new Date(fromDate),
        new Date(toDate)
      );
      setAlertReports(response);
      console.log("San Alert Report Response:", response);
      // You can update state here if you want to display the result in the UI
    } catch (error) {
      console.error("Error fetching San Alert Report:", error);
    }
  };

  const exportToExcel = () => {
    if (!alertReports || alertReports.length === 0) {
      alert("No data available to export.");
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(alertReports);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "SanReport");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    saveAs(data, "SanReport.xlsx");
  };

  // Export to CSV
  const exportToCSV = () => {
    if (!alertReports || alertReports.length === 0) {
      alert("No data available to export.");
      return;
    }

    const csvContent =
      "data:text/csv;charset=utf-8," +
      [
        ["S.No", "Search Name", "Criminal Name", "Status", "Current Status", "Matching Score", "Created_at", "Remark"],
        ...alertReports.map((report, index) => [
          index + 1,
          report.searchName,
          report.criminalName,
          report.name,
          report.currentStatus,
          report.matchingScore,
          report.created_at,
          report.remark,
        ]),
      ]
        .map((e) => e.join(","))
        .join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "SanReport.csv");
    document.body.appendChild(link);
    link.click();
  };

  // Export to PDF
  const exportToPDF = () => {
    if (!alertReports || alertReports.length === 0) {
      alert("No data available to export.");
      return;
    }

    const doc = new jsPDF();
    doc.text("San Report", 20, 10);

    autoTable(doc, {
      head: [["S.No", "Search Name", "Criminal Name", "Status", "Current Status", "Matching Score", "Created_at", "Remark"]],
      body: alertReports.map((report, index) => [
        index + 1,
        report.searchName,
        report.criminalName,
        report.name,
        report.currentStatus,
        report.matchingScore,
        report.created_at,
        report.remark,
      ]),
    });

    doc.save("SanReport.pdf");
  };

  return (
    <Box sx={{ display: "flex" }}>
      <Header />
      <Box component="main" sx={{ flexGrow: 1, p: 3, m: 4 }}>
        <Box>
          <h6 className='allheading'>Alert Report</h6>


          <Box>
            <Box
              display="flex"
              flexWrap="wrap"
              alignItems="center"

              gap={2}

            >
              <Grid container spacing={2}>
                <Grid item xs={2}>
                  <FormControl fullWidth>
                    <InputLabel>User</InputLabel>
                    <Select
                      label="User"
                      multiple
                      value={selectedUserIds}
                      onChange={handleUserChange}
                      size="small"
                      renderValue={(selected) =>
                        (selected as string[])
                          .map(id => users.find(u => u.id.toString() === id)?.userName)
                          .join(', ')
                      }
                    >
                      {users.map((user) => (
                        <MenuItem key={user.id} value={user.id.toString()}>
                          {user.userName}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>


                  <Box mt={1} display="flex" flexWrap="wrap" gap={1}>
                    {selectedUserIds.map((id) => {
                      const userName = users.find(u => u.id.toString() === id)?.userName;
                      return (
                        <Chip
                          key={id}
                          label={userName}
                          onDelete={() => {
                            setSelectedUserIds(prev => prev.filter(i => i !== id));
                          }}
                          size="small"
                        />
                      );
                    })}
                  </Box>
                </Grid>
                <Grid item xs={2}>
                  <FormControl fullWidth>
                    <InputLabel>User</InputLabel>
                    <Select
                      label="User"
                      multiple
                      value={selectedStatuses}
                      onChange={handleStatusChange}
                      size="small"
                      renderValue={(selected) =>
                        (selected as (string | number)[])
                          .map(id => statuses.find(s => s.id === Number(id))?.name)
                          .filter(Boolean)
                          .join(', ')
                      }
                    >
                      {statuses.map((user) => (
                        <MenuItem key={user.id} value={user.id.toString()}>
                          {user.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>


                  <Box mt={1} display="flex" flexWrap="wrap" gap={1}>
                    {selectedStatuses.map((id) => {
                      const status = statuses.find((status) => status.id === Number(id));
                      return status ? (
                        <Chip
                          key={id}
                          label={status.name}
                          onDelete={() => {
                            setSelectedStatuses(prev => prev.filter(i => i !== id));
                          }}
                          size="small"
                        />
                      ) : null;
                    })}
                  </Box>
                </Grid>
                <Grid item xs={2}>
              <TextField
                size="small"
                label="From Date"
                type="date"
                sx={{ minWidth: 250, height: 56 }}
                InputLabelProps={{ shrink: true }}
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
              />
              </Grid>
              <Grid item xs={2}>

              {/* To Date */}
              <TextField
                size="small"
                label="To Date"
                type="date"
                sx={{ minWidth: 250, height: 56 }}
                InputLabelProps={{ shrink: true }}
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
              />
              </Grid>
              </Grid>
             
            

              {/* Submit Button */}
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
              // sx={{ height: 56 }}
              >
                Submit
              </Button>
            </Box>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
              <IconButton color="primary" onClick={exportToExcel}>
                <FaFileExcel size={24} />
              </IconButton>

              <IconButton color="secondary" onClick={exportToCSV}>
                <FaFileCsv size={24} />
              </IconButton>

              <IconButton color="success" onClick={exportToPDF}>
                <FaFilePdf size={24} />
              </IconButton>
            </div>



          </Box>

          <br></br>
          <Box sx={{ mt: 3, width: "100%", overflowX: "auto" }}>
            <TableContainer
              component={Card}
              sx={{ width: "100%", maxHeight: "450px", overflowY: "auto" }} // Enables scrolling
            >
              <Table size="small" stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow>
                    <TableCell>S.No</TableCell>
                    <TableCell>Search Name</TableCell>
                    <TableCell>Criminal Name</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Current Status</TableCell>
                    <TableCell>Matching Score</TableCell>
                    <TableCell>Created_at</TableCell>
                    <TableCell>Remarks</TableCell>

                  </TableRow>
                </TableHead>
                <TableBody>
                  {alertReports.length > 0 ? (
                    alertReports.map((report, index) => (
                      <TableRow key={index}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{report.searchName}</TableCell>
                        <TableCell>{report.criminalName}</TableCell>
                        <TableCell>{report.name}</TableCell>
                        <TableCell>{report.currentStatus}</TableCell>
                        <TableCell>{report.matchingScore}</TableCell>
                        <TableCell>{report.created_at}</TableCell>
                        <TableCell>{report.remark}</TableCell>

                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} align="center">
                        No data available
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>

        </Box>
      </Box>

    </Box>
  );
}

export default SanReport;



