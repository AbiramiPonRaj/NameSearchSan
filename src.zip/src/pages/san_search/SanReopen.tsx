import React, { useEffect, useState } from "react";
import { Select, MenuItem, FormControl, InputLabel, SelectChangeEvent, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Card, Typography, Button, TextField, DialogContent, Dialog, DialogTitle, Grid, IconButton } from "@mui/material";
import Header from "../../layouts/header/header";
import SearchApiService from "../../data/services/san_search/search-api-service";
import SanAlertApiService from "../../data/services/san_search/sanAlert/sanAlert-api-service";
import { FaFileExcel, FaFileCsv, FaFilePdf } from "react-icons/fa";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import saveAs from "file-saver";

interface User {
  id: string;
  userName: string;
}

interface Status {
  id: number;
  name: string;
}

interface ReopenCase {
  closedCaseId: number;
  uid: number;
  reopenCount: number;
  reopenIds: number;
  avgReprocessingTimeSeconds: number;
  closedUpdatedAt: string;
  searchName: string;
  criminalName: string;
  reopenUids: string;
  reopenRemarks: string;
  remark: string;
  statusId: number;
  reopenstatusId: number;
  reopen_passingLevelId: number;
}

function SanReopen() {

  const [users, setUsers] = useState<User[]>([]);
  const [statuses, setStatuses] = useState<Status[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [reopenCases, setReopenCases] = useState<ReopenCase[]>([]);
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [selectedCase, setSelectedCase] = useState<ReopenCase | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const searchApi = new SearchApiService();
  const sanAlertServices = new SanAlertApiService();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersResponse, statusesResponse] = await Promise.all([
          searchApi.getSanUser(),
          sanAlertServices.getStatus(),
        ]);
        setUsers(usersResponse);
        setStatuses(statusesResponse);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleChange = (event: SelectChangeEvent<string>) => {
    setSelectedUser(event.target.value);
  };

  const handleSubmit = async () => {
    setSubmitted(true);
    if (!selectedUser) {
      setReopenCases([]);
      return;
    }
    try {
      const numericUserId = Number(selectedUser);
      if (isNaN(numericUserId)) {
        console.error("Invalid userId:", selectedUser);
        return;
      }
      const startDateValid = fromDate ? new Date(fromDate) : undefined;
      const endDateValid = toDate ? new Date(toDate) : undefined;
      const reopenResponse = startDateValid && endDateValid
        ? await sanAlertServices.getReopen(numericUserId, startDateValid, endDateValid)
        : await sanAlertServices.getReopen(numericUserId);
      setReopenCases(Array.isArray(reopenResponse) ? reopenResponse : []);
    } catch (error) {
      console.error("Error fetching reopen cases:", error);
    }
  };

  const handleRowClick = (caseData: ReopenCase) => {
    setSelectedCase(caseData);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
  };

  const getusername = (uid: string) => {
    const foundUser = users.find((c) => String(c.id) === uid);
    return foundUser ? foundUser.userName : 'Not Available';
  };

  const getusernamere = (reopenUids: string | number) => {
    if (!reopenUids) return "Not Available";
    const uidArray = String(reopenUids).split(",");
    const userNames = uidArray.map((uid) => {
      const foundUser = users.find((c) => String(c.id) === uid.trim());
      return foundUser ? foundUser.userName : "Not Available";
    });
    return userNames.join(", ");
  };

  const getreopenstatusId = (reopenstatusId: string) => {
    const foundUser = statuses.find((c) => String(c.id) === reopenstatusId);
    return foundUser ? foundUser.name : 'Not Available';
  };

  const getClosedstatusId = (statusId: string) => {
    const foundUser = statuses.find((c) => String(c.id) === statusId);
    return foundUser ? foundUser.name : 'Not Available';
  };

  const exportToCSV = () => {
    const csvData = reopenCases.map(caseData => ({
      "User Name": users.find(u => u.id === String(caseData.uid))?.userName || 'Not Available',
      "Search Name": caseData.searchName,
      "Criminal Name": caseData.criminalName,
      "Closed Case Id": caseData.closedCaseId,
      "Status": statuses.find(s => s.id === caseData.statusId)?.name || 'Not Available',
      "Reopened Count": caseData.reopenCount,
      "Closed Remark": caseData.remark,
      "Reopen Date": caseData.closedUpdatedAt,
      "Avg Reprocessing Time (Seconds)": caseData.avgReprocessingTimeSeconds
    }));
    const worksheet = XLSX.utils.json_to_sheet(csvData);
    const csv = XLSX.utils.sheet_to_csv(worksheet);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "Reopen_Report.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(reopenCases.map(caseData => ({
      "User Name": users.find(u => u.id === String(caseData.uid))?.userName || 'Not Available',
      "Search Name": caseData.searchName,
      "Criminal Name": caseData.criminalName,
      "Closed Case Id": caseData.closedCaseId,
      "Status": statuses.find(s => s.id === caseData.statusId)?.name || 'Not Available',
      "Reopened Count": caseData.reopenCount,
      "Closed Remark": caseData.remark,
      "Reopen Date": caseData.closedUpdatedAt,
      "Avg Reprocessing Time (Seconds)": caseData.avgReprocessingTimeSeconds
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Reopen Cases");
    XLSX.writeFile(workbook, "Reopen_Report.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Reopen Report", 14, 10);
    autoTable(doc, {
      startY: 20,
      head: [["User Name", "Search Name", "Criminal Name", "Closed Case Id", "Status", "Reopened Count", "Closed Remark", "Reopen Date", "Avg Reprocessing Time"]],
      body: reopenCases.map(caseData => ([
        users.find(u => u.id === String(caseData.uid))?.userName || 'Not Available',
        caseData.searchName,
        caseData.criminalName,
        caseData.closedCaseId,
        statuses.find(s => s.id === caseData.statusId)?.name || 'Not Available',
        caseData.reopenCount,
        caseData.remark,
        caseData.closedUpdatedAt,
        caseData.avgReprocessingTimeSeconds
      ])),
      styles: { fontSize: 8 }
    });
    doc.save("Reopen_Report.pdf");
  };

  return (
    <Box sx={{ display: "flex" }}>
      <Header />
      <Box component="main" sx={{ flexGrow: 1, p: 3, m: 5 }}>
        <h6 className="allheading">Reopen Report</h6>
        <Grid container spacing={2} alignItems="center" sx={{ flexWrap: "wrap" }}>
          <Grid item xs={3}>
            <FormControl fullWidth >
              <InputLabel>User</InputLabel>
              <Select label="User" value={selectedUser} onChange={handleChange}>
                <MenuItem value={""} style={{ color: "gray" }}>Select User</MenuItem>
                {users.map((user) => (
                  <MenuItem key={user.id} value={user.id}>{user.userName}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={2}>
            <TextField
              label="From Date"
              type="date"
              size="small"
              InputLabelProps={{ shrink: true }}
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={2}>
            <TextField
              label="To Date"
              type="date"
              size="small"
              InputLabelProps={{ shrink: true }}
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={2} sx={{ display: "flex", justifyContent: { xs: "center", md: "flex-start" } }}>
            <Button variant="contained" color="primary" onClick={handleSubmit} fullWidth={false}>
              Submit
            </Button>
          </Grid>
          <Grid item xs={12} md={3} sx={{ display: "flex", justifyContent: { xs: "center", md: "flex-end" } }}>
            <IconButton color="primary" onClick={exportToExcel}><FaFileExcel size={24} /></IconButton>
            <IconButton color="secondary" onClick={exportToCSV}><FaFileCsv size={24} /></IconButton>
            <IconButton color="success" onClick={exportToPDF}><FaFilePdf size={24} /></IconButton>
          </Grid>
        </Grid>
        {reopenCases.length > 0 ? (
          <TableContainer component={Card} sx={{ width: "100%", maxHeight: "450px", overflowY: "auto", marginTop: 2 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>User Name</TableCell>
                  <TableCell >Reopened Count</TableCell>
                  <TableCell>Reopen Date</TableCell>
                  <TableCell>Closed Case Id</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Closed Remark</TableCell>
                  <TableCell>Avg Reprocessing Time</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {reopenCases.map((caseData, index) => (
                  <TableRow key={index}>
                    <TableCell>{getusername(String(caseData.uid))}</TableCell>
                    <TableCell
                      style={{ color: "blue", textDecoration: "underline", cursor: "pointer" }}
                      onClick={() => handleRowClick(caseData)}
                    >
                      {caseData.reopenCount}
                    </TableCell>
                    <TableCell>{caseData.closedUpdatedAt}</TableCell>
                    <TableCell>{caseData.closedCaseId}</TableCell>
                    <TableCell>{statuses.find(s => s.id === caseData.statusId)?.name || 'Not Available'}</TableCell>
                    <TableCell>{caseData.remark}</TableCell>
                    <TableCell>{caseData.avgReprocessingTimeSeconds}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : submitted && (
          <Typography sx={{ mt: 2, color: "gray" }}>No reopen cases found for the selected user.</Typography>
        )}
      </Box>
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="lg" >
        <DialogTitle style={{ fontSize: "14px", fontFamily: '"Bookman Old Style", serif' }}>
          Reopen Case Details
        </DialogTitle>
        <DialogContent>
          {selectedCase && (
            <Box>
              <TableContainer component={Card}>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell><b>Reopen Case ID</b></TableCell>
                      <TableCell><b>Reopen Date</b></TableCell>
                      <TableCell><b>Reopen User Name</b></TableCell>
                      <TableCell>Search Name</TableCell>
                      <TableCell>Criminal Name</TableCell>
                      <TableCell><b>Reopen Status</b></TableCell>
                      <TableCell><b>Reopen passingLeve</b></TableCell>
                      <TableCell><b>Reopen Remarks</b></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedCase.reopenIds
                      ? String(selectedCase.reopenIds)
                        .split(",")
                        .map((id, index) => {
                          const reopenUidsArray: string[] = Array.isArray(selectedCase.reopenUids)
                            ? selectedCase.reopenUids
                            : String(selectedCase.reopenUids).split(",");
                          let reopenRemarksArray: string[] = [];
                          if (Array.isArray(selectedCase.reopenRemarks)) {
                            reopenRemarksArray = selectedCase.reopenRemarks as string[];
                          } else if (typeof selectedCase.reopenRemarks === "string") {
                            reopenRemarksArray = selectedCase.reopenRemarks.split("|");
                          }
                          const reopenStatusArray: string[] = Array.isArray(selectedCase.reopenstatusId)
                            ? selectedCase.reopenstatusId
                            : String(selectedCase.reopenstatusId).split(",");
                          const reopenLevelArray: string[] = Array.isArray(selectedCase.reopen_passingLevelId)
                            ? selectedCase.reopen_passingLevelId
                            : String(selectedCase.reopen_passingLevelId).split(",");
                          return (
                            <TableRow key={index}>
                              <TableCell>{id.trim()}</TableCell>
                              <TableCell>{selectedCase.closedUpdatedAt || "No Data Available"}</TableCell>
                              <TableCell>{getusernamere(reopenUidsArray?.[index]?.trim()) || "No Data Available"}</TableCell>
                              <TableCell>{selectedCase.searchName}</TableCell>
                              <TableCell>{selectedCase.criminalName}</TableCell>
                              <TableCell>{getreopenstatusId(reopenStatusArray?.[index]?.trim()) || "No Data Available"}</TableCell>
                              <TableCell>{(reopenLevelArray?.[index]?.trim()) || "No Data Available"}</TableCell>
                              <TableCell>
                                {reopenRemarksArray.length > index
                                  ? reopenRemarksArray[index]?.trim()
                                  : "No Data Available"}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      : (
                        <TableRow>
                          <TableCell colSpan={5} align="center">No Data Available</TableCell>
                        </TableRow>
                      )}
                  </TableBody>
                </Table>
              </TableContainer>
              <br></br>
              <Typography><b>Avg Reprocessing Time (Seconds):</b> {selectedCase.avgReprocessingTimeSeconds || "No Data Available"}</Typography>
            </Box>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}

export default SanReopen;