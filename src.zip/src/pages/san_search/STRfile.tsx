import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  Typography,
  TextField,
  Button,
  IconButton,
  Grid
} from "@mui/material";
import SanAlertApiService from "../../data/services/san_search/sanAlert/sanAlert-api-service";
import Header from "../../layouts/header/header";
import { FaFileExcel, FaFileCsv, FaFilePdf } from "react-icons/fa";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import saveAs from "file-saver";

interface STRFile {
  strFileCount: number;
  searchName: string;
  criminalName: string;
  statusId: number;
  passinglevelId: number;
}

function STRfile() {
  const [strFiles, setStrFiles] = useState<STRFile[]>([]);
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const sanAlertServices = new SanAlertApiService();

  const fetchData = async () => {
    try {
      if (!fromDate || !toDate) {
        setError("Please select both From Date and To Date.");
        return;
      }

      setLoading(true);
      setError(null);

      const response = await sanAlertServices.getSTRfile(new Date(fromDate), new Date(toDate));
      setStrFiles(response);
      console.log("STR File Data:", response);
    } catch (error) {
      setError("Error fetching STR files.");
      console.error("Error fetching STR files:", error);
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(strFiles);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "STR Files");
    XLSX.writeFile(workbook, "STR_File_Data.xlsx");
  };

  const exportToCSV = () => {
    if (strFiles.length === 0) {
      alert("No data available to export.");
      return;
    }

    const headers = ["Search Name, Criminal Name, STR File Count, Status, Passing Level"];
    const rows = strFiles.map(file =>
      `${file.searchName},${file.criminalName},${file.strFileCount},${file.statusId},${file.passinglevelId}`
    );

    const csvContent = [headers, ...rows].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "STR_File_Data.csv");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("STR File Data", 14, 10);

    autoTable(doc, {
      head: [["Search Name", "Criminal Name", "STR File Count", "Status", "Passing Level"]],
      body: strFiles.map(file => [
        file.searchName,
        file.criminalName,
        file.strFileCount,
        file.statusId,
        file.passinglevelId
      ])
    });

    doc.save("STR_File_Data.pdf");
  };

  return (
    <Box sx={{ display: "flex" }}>
      <Header />
      <Box component="main" sx={{ flexGrow: 1, p: 3, m: 5 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>STR File Data</Typography>

        {/* Filters and Actions */}
        <Grid container spacing={2} alignItems="center">
          {/* Date Pickers */}
          <Grid item xs={3}>
            <TextField
              size="small"
              label="From Date"
              type="date"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
            />
          </Grid>

          <Grid item xs={3} >
            <TextField
              size="small"
              label="To Date"
              type="date"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
            />
          </Grid>

          {/* Fetch Button */}
          <Grid item xs={2} >
            <Button fullWidth variant="contained" onClick={fetchData}>Fetch Data</Button>
          </Grid>

          {/* Export Icons - Right Aligned */}
          <Grid item xs={12} md={3} sx={{ display: "flex", justifyContent: "flex-end" }}>
            <IconButton color="primary" onClick={exportToExcel}>
              <FaFileExcel size={24} />
            </IconButton>

            <IconButton color="secondary" onClick={exportToCSV}>
              <FaFileCsv size={24} />
            </IconButton>

            <IconButton color="success" onClick={exportToPDF}>
              <FaFilePdf size={24} />
            </IconButton>
          </Grid>
        </Grid>
<br></br>
        {/* Table Display */}
        {loading ? (
          <Typography>Loading...</Typography>
        ) : error ? (
          <Typography color="error">{error}</Typography>
        ) : strFiles.length === 0 ? (
          <Typography>No Data Available</Typography>
        ) : (
          <TableContainer component={Paper} sx={{ mt: 2 }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ backgroundColor: "#e0e0e0" }}>
                  <TableCell><b>Search Name</b></TableCell>
                  <TableCell><b>Criminal Name</b></TableCell>
                  <TableCell><b>STR File Count</b></TableCell>
                  <TableCell><b>Status</b></TableCell>
                  <TableCell><b>Passing Level</b></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {strFiles.map((file, index) => (
                  <TableRow key={index}>
                    <TableCell>{file.searchName}</TableCell>
                    <TableCell>{file.criminalName}</TableCell>
                    <TableCell>{file.strFileCount}</TableCell>
                    <TableCell>{file.statusId}</TableCell>
                    <TableCell>{file.passinglevelId}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>
    </Box>
  );
}

export default STRfile;
