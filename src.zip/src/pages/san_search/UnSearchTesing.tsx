import { useEffect, useState } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Card, Button, Select, MenuItem, SelectChangeEvent, Box, FormControl, InputLabel, TextField, Typography, Slider, CircularProgress } from "@mui/material";
import ViewService from "../../data/services/san_search/viewpage/view_api_service";
import { Country } from "../../data/services/san_search/viewpage/view_payload";
import Header from "../../layouts/header/header";
import CountApiService from "../../data/services/san_search/countapi/count_api_service";

interface All {
    name: string,
    id: string
}

function Tesing() {

    const [selectedFileType, setSelectedFileType] = useState<number>(0);
    const [selectedRecordType, setSelectedRecordType] = useState<number>(1);
    const [RecordType, setRecordType] = useState<All[]>([]);
    const [selectedCountry, setSelectedCountry] = useState<number>(0);
    const [country, setCountry] = useState<Country[]>([]);
    const [sliderValue, setSliderValue] = useState<number>(80);
    const [loading, setLoading] = useState(false);
    const [searchTriggered, setSearchTriggered] = useState(false);

    const viewservice = new ViewService();
    const countApiService = new CountApiService();

    const [formData, setFormData] = useState({
        name: "",
        dob: "",
        id: "",
    });

    const [nameError, setNameError] = useState<string>("");
    const [searchResults, setSearchResults] = useState<any[]>([]);

    useEffect(() => {
        fetchCountry();
        fetchAll();
    }, []);

    const fetchCountry = async () => {
        try {
            const countryData = await viewservice.getCountryList();
            setCountry(countryData);
        } catch (error) {
            console.error("Error fetching country list:", error);
        }
    };

    const fetchAll = async () => {
        try {
            const allData = await viewservice.getAlltype();
            setRecordType(allData);
        } catch (error) {
            console.error("Error fetching record type list:", error);
        }
    };

    const handleRecordTypeChange = (event: SelectChangeEvent<any>) => {
        setSelectedFileType(Number(event.target.value));
    };

    const handleCountryChange = (event: SelectChangeEvent<any>) => {
        setSelectedCountry(Number(event.target.value));
    };

    const handleSearch = async () => {
        setSearchTriggered(true);
        if (!formData.name.trim()) {
            setNameError("Name is required");
            return;
        }
        const dto = {
            name: formData.name,
            dob: formData.dob,
            id: formData.id,
            country: selectedCountry.toString(),
            // entityType: selectedFileType,
            entityType: 1,
            score: sliderValue,
        };
        setLoading(true);
        try {
            const result = await countApiService.getUnSearchSanctioned(dto, selectedFileType);
            console.log('Results:', result);
            if (!Array.isArray(result)) {
                console.error("Expected an array but got:", result);
                return;
            }
            const mappedResults = result.map((item) => ({
                name: item.name,
                id: item.id,
                waitRate1: item.onsideMultiPara[1] || 0,
                waitRate2: item.onsideMultiPara[2] || 0,
                waitRate3: item.onsideMultiPara[3] || 0,
                waitRate4: item.onsideMultiPara[4] || 0,
                waitRate5: item.onsideMultiPara[5] || 0,
                similarity1: item.onsideMultiPara[6] || 0,
                similarity2: item.onsideMultiPara[7] || 0,
                similarity3: item.onsideMultiPara[8] || 0,
                similarity4: item.onsideMultiPara[9] || 0,
                similarity5: item.onsideMultiPara[10] || 0,
            }));
            setSearchResults(mappedResults);
        } catch (error) {
            console.error("Error during search:", error);
        }
        finally {
            setLoading(false);
        }
    };

    const handleReset = () => {
        setSelectedRecordType(0);
        setSelectedCountry(0);
        setSliderValue(80);
        setSelectedFileType(0);
        setFormData({
            name: "",
            dob: "",
            id: "",
        });
        setNameError("");
        setSearchResults([]);
    };

    return (
        <Box sx={{ display: "flex" }}>
            <Header />
            <Box component="main" sx={{ flexGrow: 1, p: 1, mt: 7 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                    <h6 className='allheading'>Un Search</h6>
                </Box>
                <Card style={{ padding: '1%', boxShadow: 'rgb(0 0 0 / 28%) 0px 4px 8px', width: '100%' }}>
                    <div style={{ display: 'flex', gap: '1%' }}>
                        <FormControl fullWidth size="small">
                            <InputLabel id="record-type-label">Type</InputLabel>
                            <Select
                                labelId="record-type-label"
                                value={selectedFileType}
                                onChange={handleRecordTypeChange}
                                label="Type"
                            >
                                <MenuItem value={0}>All</MenuItem>
                                {RecordType.map((item) => (
                                    <MenuItem key={item.id} value={item.id}>
                                        {item.name}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <TextField
                            fullWidth
                            label="Name"
                            size="small"
                            variant="outlined"
                            value={formData.name}
                            onChange={(e) => {
                                setFormData({ ...formData, name: e.target.value });
                                if (nameError) setNameError("");
                            }}
                        />
                        {nameError && <Typography color="error">{nameError}</Typography>}
                        <TextField
                            fullWidth
                            label="Id"
                            size="small"
                            variant="outlined"
                            value={formData.id}
                            onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                        />
                        <TextField
                            fullWidth
                            size="small"
                            label="DOB"
                            type="date"
                            variant="outlined"
                            value={formData.dob}
                            onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                            InputLabelProps={{ shrink: true }}
                            InputProps={{
                                sx: {
                                    height: 35,
                                    fontSize: '12px',
                                    fontFamily: 'Bookman Old Style',
                                },
                            }}
                        />
                        <FormControl fullWidth size="small">
                            <InputLabel>Country</InputLabel>
                            <Select value={selectedCountry} onChange={handleCountryChange} label="Country">
                                <MenuItem value={0}>All</MenuItem>
                                {country.map((item) => (
                                    <MenuItem key={item.primaryKey} value={item.primaryKey}>
                                        {item.text}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <Slider className="custom-textfield .MuiInputBase-root"
                            style={{ width: '90%' }}
                            value={sliderValue}
                            onChange={(e, newValue) => setSliderValue(newValue as number)}
                            step={1}
                            marks
                            min={50}
                            max={100}
                        />
                        <TextField className="custom-textfield .MuiInputBase-root"
                            style={{ width: '50%' }}
                            label="Score"
                            size="small"
                            type="number"
                            value={sliderValue}
                            onChange={(e) => setSliderValue(parseInt(e.target.value))}
                        />
                        <Button variant="contained" color="primary" onClick={handleSearch}>
                            Search
                        </Button>
                        <Button variant="outlined" color="primary" onClick={handleReset}>
                            Reset
                        </Button>
                    </div>
                </Card>
                <Box mt={4}>
                    <TableContainer
                        className="table-container"
                        component={Card}
                        style={{
                            maxHeight: 340,
                            overflowY: "auto",
                        }}
                    >
                        <Table
                            size="small"
                            stickyHeader
                            aria-label="sticky table"
                            sx={{
                                tableLayout: 'auto',
                                width: '100%',
                                minWidth: 1200,
                                borderCollapse: 'collapse',
                                '& th, & td': {
                                    border: '1px solid rgba(224, 224, 224, 1)',
                                },
                                '& thead th': {
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 2,
                                    backgroundColor: '#f5f5f5',
                                },
                                '& thead tr:nth-of-type(2) th': {
                                    top: 34,
                                    zIndex: 1,
                                },
                            }}
                        >
                            <TableHead>
                                <TableRow>
                                    <TableCell rowSpan={2}>S.No</TableCell>
                                    <TableCell rowSpan={2}>Name</TableCell>
                                    <TableCell rowSpan={2}>ID</TableCell>
                                    <TableCell colSpan={5} align="center">
                                        Wait Rate
                                    </TableCell>
                                    <TableCell colSpan={5} align="center">
                                        Similarity
                                    </TableCell>
                                </TableRow>
                                <TableRow>
                                    {[1, 2, 3, 4, 5].map((i) => (
                                        <TableCell key={`w${i}`}>Algorithm {i}</TableCell>
                                    ))}
                                    {[1, 2, 3, 4, 5].map((i) => (
                                        <TableCell key={`s${i}`}>Algorithm {i}</TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {loading ? (
                                    <TableRow>
                                        <TableCell colSpan={13} align="center">
                                            <Typography variant="body2" color="textSecondary">
                                                <Box display="flex" justifyContent="center" alignItems="center" py={2}>
                                                    <CircularProgress size={24} />
                                                    <Box ml={2}>Loading...</Box>
                                                </Box>
                                            </Typography>
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    searchResults.map((row, index) => (
                                        <TableRow key={index}>
                                            <TableCell>{index + 1}</TableCell>
                                            <TableCell>{row.name}</TableCell>
                                            <TableCell>{row.id}</TableCell>
                                            <TableCell>{row.waitRate1}</TableCell>
                                            <TableCell>{row.waitRate2}</TableCell>
                                            <TableCell>{row.waitRate3}</TableCell>
                                            <TableCell>{row.waitRate4}</TableCell>
                                            <TableCell>{row.waitRate5}</TableCell>
                                            <TableCell>{row.similarity1}</TableCell>
                                            <TableCell>{row.similarity2}</TableCell>
                                            <TableCell>{row.similarity3}</TableCell>
                                            <TableCell>{row.similarity4}</TableCell>
                                            <TableCell>{row.similarity5}</TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            </Box>
        </Box>
    );
}

export default Tesing;