import React, { useState, useEffect } from "react";
import {
    Box,
    MenuItem,
    FormControl,
    InputLabel,
    Select,
    OutlinedInput,
    Chip,
    TextField,
    Button,
    TableContainer,
    Table,
    TableHead,
    TableRow,
    Paper,
    TableCell,
    TableBody,
    Card,
    IconButton,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import LevelStatusMappingApiService from "../../data/services/san_search/levelstatusmapping/levelstatusmapping-api-service";
import SearchApiService from "../../data/services/san_search/search-api-service";
import { useSelector } from "react-redux";
import Header from "../../layouts/header/header";
import SanAlertApiService from '../../data/services/san_search/sanAlert/sanAlert-api-service';
import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import saveAs from "file-saver";
import { Download, PictureAsPdf, TableChart } from "@mui/icons-material";
import { FaFileExcel, FaFileCsv, FaFilePdf } from "react-icons/fa";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";

interface Status {
    id: number;
    name: string;

}

interface User {
    id: string;
    userName: string;
}
interface AlertReport {
    name: string;
    searchName: string;
    searchId: number;
    hitId: number;
    criminalId: number;
    criminalName: string;
    matchingScore: number;
    remark: string;
    caseId: number;
    fileType: number;
    uid: number;
    created_at: string;
    currentStatus: string

}

function SanReportMonth() {
    const [users, setUsers] = useState<User[]>([]);
    const [statuses, setStatuses] = useState<Status[]>([]);
    const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
    const [selectedStatuses, setSelectedStatuses] = useState<number[]>([]);
    const [selectedMonth, setSelectedMonth] = useState<Date | null>(null);
    const [selectedYear, setSelectedYear] = useState<Date | null>(null);
    const [selectedendMonth, setSelectedendMonth] = useState<Date | null>(null);
    const [selectedendYear, setSelectedendYear] = useState<Date | null>(null);
    const [alertReports, setAlertReports] = useState<AlertReport[]>([]);

    const userDetails = useSelector((state: any) => state.loginReducer);
    const loginDetails = userDetails.loginDetails;
    const levelService = new LevelStatusMappingApiService();
    const searchApi = new SearchApiService();
    const sanAlertServices = new SanAlertApiService();
    useEffect(() => {
        const fetchData = async () => {
            try {
                const [usersResponse, statusesResponse] = await Promise.all([
                    searchApi.getSanUser(),
                    sanAlertServices.getStatus(),
                ]);
                setUsers(usersResponse);
                setStatuses(statusesResponse);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, [loginDetails]);

    // Handle User Selection
    const handleUserChange = (event: any) => {
        setSelectedUserIds(event.target.value);
    };

    // Handle Status Selection
    const handleStatusChange = (event: any) => {
        setSelectedStatuses(event.target.value);
    };

    // Handle User Deletion
    const handleUserDelete = (id: string) => {
        setSelectedUserIds((prev) => prev.filter((userId) => userId !== id));
    };

    // Handle Status Deletion
    const handleStatusDelete = (id: number) => {
        setSelectedStatuses((prev) => prev.filter((statusId) => statusId !== id));
    };
 
    
    const handleSubmit = async () => {
        if (!selectedUserIds.length || !selectedStatuses.length || !selectedMonth || !selectedYear || !selectedendMonth || !selectedendYear) {
            alert("Please select users, statuses, and date range.");
            return;
        }
    
        try {
            const monthString = (selectedMonth.getMonth() + 1).toString().padStart(2, "0"); // Ensures "01"-"12"
            const yearString = selectedYear.getFullYear().toString();
            
            // Use optional chaining to prevent errors
            const monthendString = ((selectedendMonth?.getMonth() || new Date().getMonth()) + 1)
                .toString()
                .padStart(2, "0"); // Ensures "01"-"12"
            
            const yearendString = (selectedendYear?.getFullYear() || new Date().getFullYear()).toString();
    
            console.log("Selected Month:", monthString);
            console.log("Selected Year:", yearString);
            console.log("Selected End Month:", monthendString);
            console.log("Selected End Year:", yearendString);
    
            const response = await sanAlertServices.getSanAlertReportMonth(
                selectedUserIds,  
                selectedStatuses, 
                monthString,    
                yearString,
                monthendString,
                yearendString    
            );
    
            setAlertReports(response);
            console.log("San Alert Report Response:", response);
        } catch (error) {
            console.error("Error fetching San Alert Report:", error);
        }
    };
    

    const exportToExcel = () => {
        if (!alertReports || alertReports.length === 0) {
            alert("No data available to export.");
            return;
        }

        const worksheet = XLSX.utils.json_to_sheet(alertReports);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "SanReportMonth");
        const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
        const data = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        saveAs(data, "SanReportMonth.xlsx");
    };

    // Export to CSV
    const exportToCSV = () => {
        if (!alertReports || alertReports.length === 0) {
            alert("No data available to export.");
            return;
        }

        const csvContent =
            "data:text/csv;charset=utf-8," +
            [
                ["S.No", "Search Name", "Criminal Name", "Status", "Current Status", "Matching Score", "Created_at", "Remark"],
                ...alertReports.map((report, index) => [
                    index + 1,
                    report.searchName,
                    report.criminalName,
                    report.name,
                    report.currentStatus,
                    report.matchingScore,
                    report.created_at,
                    report.remark,
                ]),
            ]
                .map((e) => e.join(","))
                .join("\n");

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "SanReportMonth.csv");
        document.body.appendChild(link);
        link.click();
    };

    // Export to PDF
    const exportToPDF = () => {
        if (!alertReports || alertReports.length === 0) {
            alert("No data available to export.");
            return;
        }

        const doc = new jsPDF();
        doc.text("San Report Month", 20, 10);

        autoTable(doc, {
            head: [["S.No", "Search Name", "Criminal Name", "Status", "Current Status", "Matching Score", "Created_at", "Remark"]],
            body: alertReports.map((report, index) => [
                index + 1,
                report.searchName,
                report.criminalName,
                report.name,
                report.currentStatus,
                report.matchingScore,
                report.created_at,
                report.remark,
            ]),
        });

        doc.save("SanReportMonth.pdf");
    };

    return (
        <Box sx={{ display: "flex" }}>
            <Header />
            <Box component="main" sx={{ flexGrow: 1, p: 3, m: 4 }}>
                <Box>
                    <h6 className='allheading'>Month Report</h6>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <Box>
                        <Box
                            display="flex"
                            flexWrap="wrap"
                            alignItems="center"

                            gap={2}

                        >            {/* User Selection */}

                            <FormControl sx={{ minWidth: 250, height: 56 }}>
                                <InputLabel>User</InputLabel>
                                <Select
                                    multiple
                                    value={selectedUserIds}
                                    onChange={handleUserChange}
                                    input={<OutlinedInput label="User" />}
                                    renderValue={(selected) => (
                                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5, }}>
                                            {selected.map((id) => {
                                                const user = users.find((user) => user.id === id);
                                                return user ? (
                                                    <Chip
                                                        key={id}
                                                        size="small"
                                                        label={user.userName}
                                                        sx={{ backgroundColor: "#e0e0e0", color: "#000" }}
                                                    />
                                                ) : null;
                                            })}
                                        </Box>
                                    )}
                                >
                                    {users.map((user) => (
                                        <MenuItem key={user.id} value={user.id}>
                                            {user.userName}
                                        </MenuItem>
                                    ))}
                                </Select>
                                <Box>
                                    {selectedUserIds.map((id) => {
                                        const user = users.find((user) => user.id === id);
                                        return user ? (
                                            <Chip
                                                key={id}
                                                size="small"
                                                label={user.userName}
                                                onDelete={() => handleUserDelete(id)}
                                            />
                                        ) : null;
                                    })}
                                </Box>
                            </FormControl>

                            {/* Status Selection */}
                            <FormControl sx={{ minWidth: 250, height: 56 }} >
                                <InputLabel>Status</InputLabel>
                                <Select
                                    multiple
                                    value={selectedStatuses}
                                    onChange={handleStatusChange}
                                    input={<OutlinedInput label="Status" />}
                                    renderValue={(selected) => (
                                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                                            {selected.map((id) => (
                                                <Chip
                                                    key={id}
                                                    size="small"
                                                    label={statuses.find((status) => status.id === id)?.name || id}
                                                />
                                            ))}
                                        </Box>
                                    )}
                                >
                                    {statuses.map((status) => (
                                        <MenuItem key={status.id} value={status.id}>
                                            {status.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                                <Box>
                                    {selectedStatuses.map((id) => {
                                        const status = statuses.find((status) => status.id === id);
                                        return status ? (
                                            <Chip
                                                key={id}
                                                label={status.name}
                                                onDelete={() => handleStatusDelete(id)}
                                            />
                                        ) : null;
                                    })}
                                </Box>
                            </FormControl>

                            {/* From Date */}
                            <DatePicker
                                views={["month"]}
                                label="Select Start Month"
                                value={selectedMonth}
                                onChange={(newValue) => setSelectedMonth(newValue)}
                                slotProps={{ textField: { sx: { minWidth: 250 } } }}
                            />
                            <DatePicker
                                views={["year"]}
                                label="Select Start Year"
                                value={selectedYear}
                                onChange={(newValue) => setSelectedYear(newValue)}
                                slotProps={{ textField: { sx: { minWidth: 250 } } }}
                            />
                                 {/* end Date */}
                             <DatePicker
                                views={["month"]}
                                label="Select End Month"
                                value={selectedendMonth}
                                onChange={(newValue) => setSelectedendMonth(newValue)}
                                slotProps={{ textField: { sx: { minWidth: 250 } } }}
                            />
                            <DatePicker
                                views={["year"]}
                                label="Select  End Year"
                                value={selectedendYear}
                                onChange={(newValue) => setSelectedendYear(newValue)}
                                slotProps={{ textField: { sx: { minWidth: 250 } } }}
                            />

                            {/* Submit Button */}
                            <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={handleSubmit}
                            // sx={{ height: 56 }}
                            >
                                Submit
                            </Button>
                            </div>
                            </Box>
                                   <div style={{ display: "flex", justifyContent: "flex-end",  }}>
                            
                                <IconButton color="primary" onClick={exportToExcel}>
                                    <FaFileExcel size={24} />
                                </IconButton>

                                <IconButton color="secondary" onClick={exportToCSV}>
                                    <FaFileCsv size={24} />
                                </IconButton>

                                <IconButton color="success" onClick={exportToPDF}>
                                    <FaFilePdf size={24} />
                                </IconButton>
                            </div>



                        </Box>
                    </LocalizationProvider>
                    <br></br>
                    <Box sx={{ mt: 3, width: "100%", overflowX: "auto" }}>
                        <TableContainer
                            component={Card}
                            sx={{ width: "100%", maxHeight: "450px", overflowY: "auto" }} // Enables scrolling
                        >
                            <Table size="small" stickyHeader aria-label="sticky table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>S.No</TableCell>
                                        <TableCell>Search Name</TableCell>
                                        <TableCell>Criminal Name</TableCell>
                                        <TableCell>Status</TableCell>
                                        <TableCell>Current Status</TableCell>
                                        <TableCell>Matching Score</TableCell>
                                        <TableCell>Created_at</TableCell>
                                        <TableCell>Remarks</TableCell>

                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {alertReports.length > 0 ? (
                                        alertReports.map((report, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{index + 1}</TableCell>
                                                <TableCell>{report.searchName}</TableCell>
                                                <TableCell>{report.criminalName}</TableCell>
                                                <TableCell>{report.name}</TableCell>
                                                <TableCell>{report.currentStatus}</TableCell>
                                                <TableCell>{report.matchingScore}</TableCell>
                                                <TableCell>{report.created_at}</TableCell>
                                                <TableCell>{report.remark}</TableCell>

                                            </TableRow>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan={8} align="center">
                                                No data available
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>

                </Box>
            </Box>

        </Box>
    );
}

export default SanReportMonth;



