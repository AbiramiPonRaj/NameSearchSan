import { useState } from "react";
import { Box, Button, Card, FormControl, FormHelperText, Grid, InputLabel, MenuItem, Paper, Select, Slider, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import Header from "../../layouts/header/header";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import UiReciveSingleRecordService from "../../data/services/san_search/UiReciveSingleRecord/UiReciveSingleRecord-api-service";
import { SanctionsAlSearch } from "../../data/services/san_search/UiReciveSingleRecord/UiReciveSingleRecord_payload";
import Loader from "../loader/loader";

const UiReciveSingleRecord = () => {

    const [name, setName] = useState<string>("");
    const [id, setId] = useState<string>("");
    const [entityType, setEntityType] = useState<number>(0);
    const [dob, setDob] = useState<Date | null>(null);
    const [selectedCountry, setSelectedCountry] = useState<string>("");
    const [score, setScore] = useState<number>(80);
    const [searchResults, setSearchResults] = useState<SanctionsAlSearch[]>([]);
    const [loading, setLoading] = useState(false);
    const [entityTypeError, setEntityTypeError] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);

    const uiReciveSingleRecordService = new UiReciveSingleRecordService();

    const countryList =
        [
            { "id": 1, "name": "Afghanistan" }, { "id": 2, "name": "Albania" }, { "id": 3, "name": "Algeria" }, { "id": 4, "name": "Andorra" }, { "id": 5, "name": "Angola" }, { "id": 6, "name": "Antigua and Barbuda" }, { "id": 7, "name": "Argentina" }, { "id": 8, "name": "Armenia" }, { "id": 9, "name": "Australia" }, { "id": 10, "name": "Austria" }, { "id": 11, "name": "Azerbaijan" },
            { "id": 12, "name": "Bahamas" }, { "id": 13, "name": "Bahrain" }, { "id": 14, "name": "Bangladesh" }, { "id": 15, "name": "Barbados" }, { "id": 16, "name": "Belarus" }, { "id": 17, "name": "Belgium" }, { "id": 18, "name": "Belize" }, { "id": 19, "name": "Benin" }, { "id": 20, "name": "Bhutan" }, { "id": 21, "name": "Bolivia" }, { "id": 22, "name": "Bosnia and Herzegovina" }, { "id": 23, "name": "Botswana" }, { "id": 24, "name": "Brazil" },
            { "id": 25, "name": "Brunei" }, { "id": 26, "name": "Bulgaria" }, { "id": 27, "name": "Burkina Faso" }, { "id": 28, "name": "Burundi" }, { "id": 29, "name": "Cabo Verde" }, { "id": 30, "name": "Cambodia" }, { "id": 31, "name": "Cameroon" }, { "id": 32, "name": "Canada" }, { "id": 33, "name": "Central African Republic" }, { "id": 34, "name": "Chad" }, { "id": 35, "name": "Chile" }, { "id": 36, "name": "China" }, { "id": 37, "name": "Colombia" }, { "id": 38, "name": "Comoros" }, { "id": 39, "name": "Congo (Congo-Brazzaville)" }, { "id": 40, "name": "Costa Rica" }, { "id": 41, "name": "Croatia" }, { "id": 42, "name": "Cuba" }, { "id": 43, "name": "Cyprus" }, { "id": 44, "name": "Czech Republic (Czechia)" }, { "id": 45, "name": "Democratic Republic of the Congo (Congo-Kinshasa)" }, { "id": 46, "name": "Denmark" }, { "id": 47, "name": "Djibouti" }, { "id": 48, "name": "Dominica" }, { "id": 49, "name": "Dominican Republic" }, { "id": 50, "name": "East Timor (Timor-Leste)" }, { "id": 51, "name": "Ecuador" }, { "id": 52, "name": "Egypt" }, { "id": 53, "name": "El Salvador" },
            { "id": 54, "name": "Equatorial Guinea" }, { "id": 55, "name": "Eritrea" }, { "id": 56, "name": "Estonia" }, { "id": 57, "name": "Eswatini (formerly Swaziland)" }, { "id": 58, "name": "Ethiopia" }, { "id": 59, "name": "Fiji" }, { "id": 60, "name": "Finland" }, { "id": 61, "name": "France" }, { "id": 62, "name": "Gabon" }, { "id": 63, "name": "Gambia" }, { "id": 64, "name": "Georgia" }, { "id": 65, "name": "Germany" }, { "id": 66, "name": "Ghana" }, { "id": 67, "name": "Greece" }, { "id": 68, "name": "Grenada" }, { "id": 69, "name": "Guatemala" },
            { "id": 70, "name": "Guinea" }, { "id": 71, "name": "Guinea-Bissau" }, { "id": 72, "name": "Guyana" }, { "id": 73, "name": "Haiti" }, { "id": 74, "name": "Honduras" }, { "id": 75, "name": "Hungary" }, { "id": 76, "name": "Iceland" }, { "id": 77, "name": "India" }, { "id": 78, "name": "Indonesia" }, { "id": 79, "name": "Iran" }, { "id": 80, "name": "Iraq" }, { "id": 81, "name": "Ireland" }, { "id": 82, "name": "Israel" }, { "id": 83, "name": "Italy" },
            { "id": 84, "name": "Ivory Coast (Côte d'Ivoire)" }, { "id": 85, "name": "Jamaica" }, { "id": 86, "name": "Japan" }, { "id": 87, "name": "Jordan" }, { "id": 88, "name": "Kazakhstan" }, { "id": 89, "name": "Kenya" }, { "id": 90, "name": "Kiribati" }, { "id": 91, "name": "Korea, North" }, { "id": 92, "name": "Korea, South" }, { "id": 93, "name": "Kuwait" }, { "id": 94, "name": "Kyrgyzstan" }, { "id": 95, "name": "Laos" }, { "id": 96, "name": "Latvia" }, { "id": 97, "name": "Lebanon" }, { "id": 98, "name": "Lesotho" },
            { "id": 99, "name": "Liberia" }, { "id": 100, "name": "Libya" }, { "id": 101, "name": "Liechtenstein" }, { "id": 102, "name": "Lithuania" }, { "id": 103, "name": "Luxembourg" }, { "id": 104, "name": "Madagascar" }, { "id": 105, "name": "Malawi" }, { "id": 106, "name": "Malaysia" }, { "id": 107, "name": "Maldives" }, { "id": 108, "name": "Mali" }, { "id": 109, "name": "Malta" }, { "id": 110, "name": "Marshall Islands" }, { "id": 111, "name": "Mauritania" }, { "id": 112, "name": "Mauritius" }, { "id": 113, "name": "Mexico" }, { "id": 114, "name": "Micronesia" }, { "id": 115, "name": "Moldova" },
            { "id": 116, "name": "Monaco" }, { "id": 117, "name": "Mongolia" }, { "id": 118, "name": "Montenegro" }, { "id": 119, "name": "Morocco" }, { "id": 120, "name": "Mozambique" }, { "id": 121, "name": "Myanmar (Burma)" }, { "id": 122, "name": "Namibia" }, { "id": 123, "name": "Nauru" }, { "id": 124, "name": "Nepal" }, { "id": 125, "name": "Netherlands" }, { "id": 126, "name": "New Zealand" }, { "id": 127, "name": "Nicaragua" }, { "id": 128, "name": "Niger" }, { "id": 129, "name": "Nigeria" }, { "id": 130, "name": "North Macedonia (formerly Macedonia)" }, { "id": 131, "name": "Norway" },
            { "id": 132, "name": "Oman" }, { "id": 133, "name": "Pakistan" }, { "id": 134, "name": "Palau" }, { "id": 135, "name": "Panama" }, { "id": 136, "name": "Papua New Guinea" }, { "id": 137, "name": "Paraguay" }, { "id": 138, "name": "Peru" }, { "id": 139, "name": "Philippines" }, { "id": 140, "name": "Poland" }, { "id": 141, "name": "Portugal" }, { "id": 142, "name": "Qatar" }, { "id": 143, "name": "Romania" }, { "id": 144, "name": "Russia" }, { "id": 145, "name": "Rwanda" }, { "id": 146, "name": "Saint Kitts and Nevis" },
            { "id": 147, "name": "Saint Lucia" }, { "id": 148, "name": "Saint Vincent and the Grenadines" }, { "id": 149, "name": "Samoa" }, { "id": 150, "name": "San Marino" }, { "id": 151, "name": "Sao Tome and Principe" }, { "id": 152, "name": "Saudi Arabia" }, { "id": 153, "name": "Senegal" }, { "id": 154, "name": "Serbia" }, { "id": 155, "name": "Seychelles" }, { "id": 156, "name": "Sierra Leone" }, { "id": 157, "name": "Singapore" }, { "id": 158, "name": "Slovakia" }, { "id": 159, "name": "Slovenia" }, { "id": 160, "name": "Solomon Islands" }, { "id": 161, "name": "Somalia" }, { "id": 162, "name": "South Africa" }, { "id": 163, "name": "South Sudan" },
            { "id": 164, "name": "Spain" }, { "id": 165, "name": "Sri Lanka" }, { "id": 166, "name": "Sudan" }, { "id": 167, "name": "Suriname" }, { "id": 168, "name": "Sweden" }, { "id": 169, "name": "Switzerland" }, { "id": 170, "name": "Syria" }, { "id": 171, "name": "Taiwan" }, { "id": 172, "name": "Tajikistan" }, { "id": 173, "name": "Tanzania" }, { "id": 174, "name": "Thailand" }, { "id": 175, "name": "Togo" }, { "id": 176, "name": "Tonga" }, { "id": 177, "name": "Trinidad and Tobago" }, { "id": 178, "name": "Tunisia" }, { "id": 179, "name": "Turkey" }, { "id": 180, "name": "Turkmenistan" }, { "id": 181, "name": "Tuvalu" }, { "id": 182, "name": "Uganda" }, { "id": 183, "name": "Ukraine" },
            { "id": 184, "name": "United Arab Emirates" }, { "id": 185, "name": "United Kingdom" }, { "id": 186, "name": "United States" }, { "id": 187, "name": "Uruguay" }, { "id": 188, "name": "Uzbekistan" }, { "id": 189, "name": "Vanuatu" }, { "id": 190, "name": "Vatican City (Holy See)" }, { "id": 191, "name": "Venezuela" }, { "id": 192, "name": "Vietnam" }, { "id": 193, "name": "Yemen" }, { "id": 194, "name": "Zambia" }, { "id": 195, "name": "Zimbabwe" }, { "id": 196, "name": "British Virgin Islands" }, { "id": 197, "name": "Cayman Islands" }, { "id": 198, "name": "Cook Islands" }, { "id": 199, "name": "Curacao" }, { "id": 200, "name": "Falkland Islands" }, { "id": 201, "name": "Faroe Islands" }, { "id": 202, "name": "Gibraltar" }, { "id": 203, "name": "Greenland" }, { "id": 204, "name": "Guam" }, { "id": 205, "name": "Guadeloupe" }, { "id": 206, "name": "Guernsey" }, { "id": 207, "name": "Hong Kong" }, { "id": 208, "name": "Isle of Man" }, { "id": 209, "name": "Jersey" }, { "id": 210, "name": "Kosovo" }, { "id": 211, "name": "Macau" }, { "id": 212, "name": "Montserrat" }, { "id": 213, "name": "Puerto Rico" }, { "id": 214, "name": "Reunion" }, { "id": 215, "name": "U.S. Virgin Islands" }
        ];

    const handleReset = () => {
        setName("");
        setId("");
        setEntityType(0);
        setDob(null);
        setSelectedCountry("");
        setScore(80);
        setSearchResults([]);
    };

    const handleSearch = async () => {
        try {
            if (!entityType) {
                setEntityTypeError(true);
                return;
            }
            setEntityTypeError(false);
            setLoading(true);
            setHasSearched(true);
            const formattedDob = dob ? dob.toISOString().split("T")[0] : "";
            const response = await uiReciveSingleRecordService.getUiReciveSingleRecord(
                name,
                formattedDob,
                id,
                selectedCountry,
                entityType,
                score.toString()
            );
            console.log("API Response:", response);
            setSearchResults(response);
        } catch (error) {
            console.error("API Call Failed:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Header />
                <Box component="main" sx={{ flexGrow: 1, mt: 4 }}>
                    <Card style={{ padding: '1%', boxShadow: 'rgb(0 0 0 / 28%) 0px 4px 8px', width: '100%', marginTop: '3%' }}>
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <Grid container spacing={1}>
                                <Grid item xs={12} sm={6} md={2}>
                                    <TextField
                                        fullWidth
                                        label="Name"
                                        variant="outlined"
                                        size="small"
                                        value={name}
                                        autoComplete="off"
                                        onChange={(e) => setName(e.target.value)}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6} md={2}>
                                    <DatePicker
                                        label="DOB"
                                        value={dob}
                                        onChange={(newValue: Date | null) => setDob(newValue)}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                size: "small",
                                            },
                                        }}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6} md={1}>
                                    <TextField
                                        fullWidth
                                        label="ID"
                                        variant="outlined"
                                        size="small"
                                        value={id}
                                        autoComplete="off"
                                        onChange={(e) => setId(e.target.value)}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6} md={2}>
                                    <TextField
                                        select
                                        fullWidth
                                        label="Country"
                                        value={selectedCountry}
                                        onChange={(e) => setSelectedCountry(e.target.value)}
                                        size="small"
                                        variant="outlined"
                                    >
                                        {countryList.map((country) => (
                                            <MenuItem key={country.id} value={country.name}>
                                                {country.name}
                                            </MenuItem>
                                        ))}
                                    </TextField>
                                </Grid>
                                <Grid item xs={12} sm={6} md={2}>
                                    <FormControl fullWidth size="small" error={entityTypeError}>
                                        <InputLabel>Entity Type</InputLabel>
                                        <Select
                                            label="Entity Type"
                                            name="entityType"
                                            value={entityType}
                                            onChange={(e) => {
                                                const value = Number(e.target.value);
                                                setEntityType(value);
                                                if (value !== 0) {
                                                    setEntityTypeError(false);
                                                }
                                            }}
                                        >
                                            <MenuItem value={0} disabled>Select Entity Type</MenuItem>
                                            <MenuItem value="1">Individual Onboarding</MenuItem>
                                            <MenuItem value="2">Entity Onboarding</MenuItem>
                                            <MenuItem value="3">Individual Remittance</MenuItem>
                                            <MenuItem value="4">Entity Remittance</MenuItem>
                                        </Select>
                                        {entityTypeError && (
                                            <FormHelperText>Please select an Entity Type</FormHelperText>
                                        )}
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={6} md={1.5}>
                                    <Typography gutterBottom style={{ marginTop: '-8%' }}>Score</Typography>
                                    <Slider
                                        value={score}
                                        onChange={(e, newValue) => setScore(newValue as number)}
                                        aria-labelledby="score-slider"
                                        valueLabelDisplay="auto"
                                        step={1}
                                        min={0}
                                        max={100}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6} md={0.5}>
                                    <Button variant="contained" color="primary" onClick={handleSearch} size="small">Search</Button>
                                </Grid>
                                <Grid item xs={12} sm={6} md={0.5} style={{ marginLeft: '2%' }}>
                                    <Button variant="contained" color="primary" size="small" onClick={handleReset}>Reset</Button>
                                </Grid>
                            </Grid>
                        </LocalizationProvider>
                        {loading && <Loader />}
                        {searchResults.length > 0 && (
                            <TableContainer component={Paper} style={{ overflowX: 'auto' }} sx={{ maxHeight: { xs: "410px", md: "410px", lg: "410px", xl: "600px" } }}>
                                <Table size="small" stickyHeader aria-label="sticky table" style={{ margin: '0 auto' }}>
                                    <TableHead sx={{ backgroundColor: '#cccdd1' }}>
                                        <TableRow className="tableHeading">
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>S.No</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Session ID</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>UID</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Source Name</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Max Score</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Algo1</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Algo2</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Algo3</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Algo4</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Algo5</TableCell>
                                            <TableCell style={{ position: 'sticky', top: 0, backgroundColor: '#D3D3D3', fontWeight: 'bold' }}>Matched Name</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {searchResults.map((item, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{index + 1}</TableCell>
                                                <TableCell>{item.sessionID}</TableCell>
                                                <TableCell>{item.uid}</TableCell>
                                                <TableCell>{item.sourceName}</TableCell>
                                                <TableCell>{item.maxWeightageScore}</TableCell>
                                                <TableCell>{item.algorithm1WeightageScore}</TableCell>
                                                <TableCell>{item.algorithm2WeightageScore}</TableCell>
                                                <TableCell>{item.algorithm3WeightageScore}</TableCell>
                                                <TableCell>{item.algorithm4WeightageScore}</TableCell>
                                                <TableCell>{item.algorithm5WeightageScore}</TableCell>
                                                <TableCell>{item.matchedName}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        )}
                        {hasSearched && searchResults.length === 0 && !loading && (
                            <Typography variant="body1" color="textSecondary" align="center" sx={{ mt: 2, color: 'red' }}>
                                No search results found.
                            </Typography>
                        )}
                    </Card>
                </Box>
            </Box>
        </>
    );
}

export default UiReciveSingleRecord;