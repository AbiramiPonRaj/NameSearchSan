import React, { useState, useEffect } from 'react';
import { DatePicker, Tag } from 'antd';
import { Dayjs } from 'dayjs';
import { uiReciveCountryRecord } from '../../data/services/viewpage/view_payload';
import { uiCountryDtoVerify } from '../../data/services/san_search/uitestingcountry/uicountry_payload';
import Header from '../../layouts/header/header';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import UiTestingCountryService from '../../data/services/san_search/uitestingcountry/uitestingcountry-api-service';
import * as XLSX from 'xlsx';
import { Box, TextField, Button, Grid, Card, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, MenuItem, FormControl, InputLabel, Select, Checkbox, } from '@mui/material';

interface Search {
    id1: string;
    id2: string;
    country1: string[];
    country2: string[];
    dob1: string;
    dob2: string;
    name1: string;
    name2: string;
    entityType: number;
};

interface Country {
    id: number;
    name: string;
};

interface MatchResult {
    nameMatch: string;
    countryMatch: string;
    dateMatch: string;
    idMatch: string;
};

const MultipleDatePicker: React.FC = () => {

    const countryList = 
    [
        { "id": 1, "name": "Afghanistan" },
        { "id": 2, "name": "Albania" },
        { "id": 3, "name": "Algeria" },
        { "id": 4, "name": "Andorra" },
        { "id": 5, "name": "Angola" },
        { "id": 6, "name": "Antigua and Barbuda" },
        { "id": 7, "name": "Argentina" },
        { "id": 8, "name": "Armenia" },
        { "id": 9, "name": "Australia" },
        { "id": 10, "name": "Austria" },
        { "id": 11, "name": "Azerbaijan" },
        { "id": 12, "name": "Bahamas" },
        { "id": 13, "name": "Bahrain" },
        { "id": 14, "name": "Bangladesh" },
        { "id": 15, "name": "Barbados" },
        { "id": 16, "name": "Belarus" },
        { "id": 17, "name": "Belgium" },
        { "id": 18, "name": "Belize" },
        { "id": 19, "name": "Benin" },
        { "id": 20, "name": "Bhutan" },
        { "id": 21, "name": "Bolivia" },
        { "id": 22, "name": "Bosnia and Herzegovina" },
        { "id": 23, "name": "Botswana" },
        { "id": 24, "name": "Brazil" },
        { "id": 25, "name": "Brunei" },
        { "id": 26, "name": "Bulgaria" },
        { "id": 27, "name": "Burkina Faso" },
        { "id": 28, "name": "Burundi" },
        { "id": 29, "name": "Cabo Verde" },
        { "id": 30, "name": "Cambodia" },
        { "id": 31, "name": "Cameroon" },
        { "id": 32, "name": "Canada" },
        { "id": 33, "name": "Central African Republic" },
        { "id": 34, "name": "Chad" },
        { "id": 35, "name": "Chile" },
        { "id": 36, "name": "China" },
        { "id": 37, "name": "Colombia" },
        { "id": 38, "name": "Comoros" },
        { "id": 39, "name": "Congo (Congo-Brazzaville)" },
        { "id": 40, "name": "Costa Rica" },
        { "id": 41, "name": "Croatia" },
        { "id": 42, "name": "Cuba" },
        { "id": 43, "name": "Cyprus" },
        { "id": 44, "name": "Czech Republic (Czechia)" },
        { "id": 45, "name": "Democratic Republic of the Congo (Congo-Kinshasa)" },
        { "id": 46, "name": "Denmark" },
        { "id": 47, "name": "Djibouti" },
        { "id": 48, "name": "Dominica" },
        { "id": 49, "name": "Dominican Republic" },
        { "id": 50, "name": "East Timor (Timor-Leste)" },
        { "id": 51, "name": "Ecuador" },
        { "id": 52, "name": "Egypt" },
        { "id": 53, "name": "El Salvador" },
        { "id": 54, "name": "Equatorial Guinea" },
        { "id": 55, "name": "Eritrea" },
        { "id": 56, "name": "Estonia" },
        { "id": 57, "name": "Eswatini (formerly Swaziland)" },
        { "id": 58, "name": "Ethiopia" },
        { "id": 59, "name": "Fiji" },
        { "id": 60, "name": "Finland" },
        { "id": 61, "name": "France" },
        { "id": 62, "name": "Gabon" },
        { "id": 63, "name": "Gambia" },
        { "id": 64, "name": "Georgia" },
        { "id": 65, "name": "Germany" },
        { "id": 66, "name": "Ghana" },
        { "id": 67, "name": "Greece" },
        { "id": 68, "name": "Grenada" },
        { "id": 69, "name": "Guatemala" },
        { "id": 70, "name": "Guinea" },
        { "id": 71, "name": "Guinea-Bissau" },
        { "id": 72, "name": "Guyana" },
        { "id": 73, "name": "Haiti" },
        { "id": 74, "name": "Honduras" },
        { "id": 75, "name": "Hungary" },
        { "id": 76, "name": "Iceland" },
        { "id": 77, "name": "India" },
        { "id": 78, "name": "Indonesia" },
        { "id": 79, "name": "Iran" },
        { "id": 80, "name": "Iraq" },
        { "id": 81, "name": "Ireland" },
        { "id": 82, "name": "Israel" },
        { "id": 83, "name": "Italy" },
        { "id": 84, "name": "Ivory Coast (Côte d'Ivoire)" },
        { "id": 85, "name": "Jamaica" },
        { "id": 86, "name": "Japan" },
        { "id": 87, "name": "Jordan" },
        { "id": 88, "name": "Kazakhstan" },
        { "id": 89, "name": "Kenya" },
        { "id": 90, "name": "Kiribati" },
        { "id": 91, "name": "Korea, North" },
        { "id": 92, "name": "Korea, South" },
        { "id": 93, "name": "Kuwait" },
        { "id": 94, "name": "Kyrgyzstan" },
        { "id": 95, "name": "Laos" },
        { "id": 96, "name": "Latvia" },
        { "id": 97, "name": "Lebanon" },
        { "id": 98, "name": "Lesotho" },
        { "id": 99, "name": "Liberia" },
        { "id": 100, "name": "Libya" },
        { "id": 101, "name": "Liechtenstein" },
        { "id": 102, "name": "Lithuania" },
        { "id": 103, "name": "Luxembourg" },
        { "id": 104, "name": "Madagascar" },
        { "id": 105, "name": "Malawi" },
        { "id": 106, "name": "Malaysia" },
        { "id": 107, "name": "Maldives" },
        { "id": 108, "name": "Mali" },
        { "id": 109, "name": "Malta" },
        { "id": 110, "name": "Marshall Islands" },
        { "id": 111, "name": "Mauritania" },
        { "id": 112, "name": "Mauritius" },
        { "id": 113, "name": "Mexico" },
        { "id": 114, "name": "Micronesia" },
        { "id": 115, "name": "Moldova" },
        { "id": 116, "name": "Monaco" },
        { "id": 117, "name": "Mongolia" },
        { "id": 118, "name": "Montenegro" },
        { "id": 119, "name": "Morocco" },
        { "id": 120, "name": "Mozambique" },
        { "id": 121, "name": "Myanmar (Burma)" },
        { "id": 122, "name": "Namibia" },
        { "id": 123, "name": "Nauru" },
        { "id": 124, "name": "Nepal" },
        { "id": 125, "name": "Netherlands" },
        { "id": 126, "name": "New Zealand" },
        { "id": 127, "name": "Nicaragua" },
        { "id": 128, "name": "Niger" },
        { "id": 129, "name": "Nigeria" },
        { "id": 130, "name": "North Macedonia (formerly Macedonia)" },
        { "id": 131, "name": "Norway" },
        { "id": 132, "name": "Oman" },
        { "id": 133, "name": "Pakistan" },
        { "id": 134, "name": "Palau" },
        { "id": 135, "name": "Panama" },
        { "id": 136, "name": "Papua New Guinea" },
        { "id": 137, "name": "Paraguay" },
        { "id": 138, "name": "Peru" },
        { "id": 139, "name": "Philippines" },
        { "id": 140, "name": "Poland" },
        { "id": 141, "name": "Portugal" },
        { "id": 142, "name": "Qatar" },
        { "id": 143, "name": "Romania" },
        { "id": 144, "name": "Russia" },
        { "id": 145, "name": "Rwanda" },
        { "id": 146, "name": "Saint Kitts and Nevis" },
        { "id": 147, "name": "Saint Lucia" },
        { "id": 148, "name": "Saint Vincent and the Grenadines" },
        { "id": 149, "name": "Samoa" },
        { "id": 150, "name": "San Marino" },
        { "id": 151, "name": "Sao Tome and Principe" },
        { "id": 152, "name": "Saudi Arabia" },
        { "id": 153, "name": "Senegal" },
        { "id": 154, "name": "Serbia" },
        { "id": 155, "name": "Seychelles" },
        { "id": 156, "name": "Sierra Leone" },
        { "id": 157, "name": "Singapore" },
        { "id": 158, "name": "Slovakia" },
        { "id": 159, "name": "Slovenia" },
        { "id": 160, "name": "Solomon Islands" },
        { "id": 161, "name": "Somalia" },
        { "id": 162, "name": "South Africa" },
        { "id": 163, "name": "South Sudan" },
        { "id": 164, "name": "Spain" },
        { "id": 165, "name": "Sri Lanka" },
        { "id": 166, "name": "Sudan" },
        { "id": 167, "name": "Suriname" },
        { "id": 168, "name": "Sweden" },
        { "id": 169, "name": "Switzerland" },
        { "id": 170, "name": "Syria" },
        { "id": 171, "name": "Taiwan" },
        { "id": 172, "name": "Tajikistan" },
        { "id": 173, "name": "Tanzania" },
        { "id": 174, "name": "Thailand" },
        { "id": 175, "name": "Togo" },
        { "id": 176, "name": "Tonga" },
        { "id": 177, "name": "Trinidad and Tobago" },
        { "id": 178, "name": "Tunisia" },
        { "id": 179, "name": "Turkey" },
        { "id": 180, "name": "Turkmenistan" },
        { "id": 181, "name": "Tuvalu" },
        { "id": 182, "name": "Uganda" },
        { "id": 183, "name": "Ukraine" },
        { "id": 184, "name": "United Arab Emirates" },
        { "id": 185, "name": "United Kingdom" },
        { "id": 186, "name": "United States" },
        { "id": 187, "name": "Uruguay" },
        { "id": 188, "name": "Uzbekistan" },
        { "id": 189, "name": "Vanuatu" },
        { "id": 190, "name": "Vatican City (Holy See)" },
        { "id": 191, "name": "Venezuela" },
        { "id": 192, "name": "Vietnam" },
        { "id": 193, "name": "Yemen" },
        { "id": 194, "name": "Zambia" },
        { "id": 195, "name": "Zimbabwe" },
        { "id": 196, "name": "British Virgin Islands" },
        { "id": 197, "name": "Cayman Islands" },
        { "id": 198, "name": "Cook Islands" },
        { "id": 199, "name": "Curacao" },
        { "id": 200, "name": "Falkland Islands" },
        { "id": 201, "name": "Faroe Islands" },
        { "id": 202, "name": "Gibraltar" },
        { "id": 203, "name": "Greenland" },
        { "id": 204, "name": "Guam" },
        { "id": 205, "name": "Guadeloupe" },
        { "id": 206, "name": "Guernsey" },
        { "id": 207, "name": "Hong Kong" },
        { "id": 208, "name": "Isle of Man" },
        { "id": 209, "name": "Jersey" },
        { "id": 210, "name": "Kosovo" },
        { "id": 211, "name": "Macau" },
        { "id": 212, "name": "Montserrat" },
        { "id": 213, "name": "Puerto Rico" },
        { "id": 214, "name": "Reunion" },
        { "id": 215, "name": "U.S. Virgin Islands" }
      ];
      
    // const [uicountry, setCountry] = useState<Country[]>([]);
    const [uicountry, setCountry] = useState(countryList);
    const [loading, setLoading] = useState(false);
    const [searchError, setSearchError] = useState(false);
    const [searchResults, setSearchResults] = useState([]);
    // const [searchResultsArray, setSearchResultsArray] = useState([]);

    const [selectedDates, setSelectedDates] = useState<Dayjs[]>([]);
    const [selected2Dates, setSelected2Dates] = useState<Dayjs[]>([]);
    const [pickerValues, setPickerValues] = useState<Dayjs | null>(null);
    const [pickerValue, setPickerValue] = useState<Dayjs | null>(null);
    const [selectedYears, setSelectedYears] = useState<Dayjs[]>([]);
    const [startYear, setStartYear] = useState<Dayjs | null>(null);
    const [endYear, setEndYear] = useState<Dayjs | null>(null);
    const [yearRanges, setYearRanges] = useState<string[]>([]);

    const country = new UiTestingCountryService();

    useEffect(() => {
        fetchCountry();
    }, []);

    const [searchParams, setSearchParams] = useState<Search>({
        id1: '',
        id2: '',
        country1: [],
        country2: [],
        dob1: '',
        dob2: '',
        name1: '',
        name2: '',
        entityType: 0
    });

    const [matchResult, setMatchResult] = useState<MatchResult>({
        nameMatch: '0',
        countryMatch: '0',
        dateMatch: '0',
        idMatch: '0',
    });

    const handleInputChange = (event: any) => {
        const { name, value } = event.target;
        const isSelectEvent = Array.isArray(value);
        setSearchParams((prev) => ({
            ...prev,
            [name]: isSelectEvent ? value : value,
        }));
    };

    const exportToExcel = () => {
        const ws = XLSX.utils.json_to_sheet(searchResults);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        XLSX.writeFile(wb, 'search_results.xlsx');
    };

    const fetchCountry = async () => {
        try {
            const countryData = await country.getUICountry();
            const formattedCountryData = countryData.map((name: any, index: number) => ({
                id: index + 1,
                name,
            }));
            console.log("Formatted country data:", formattedCountryData);
            setCountry(formattedCountryData);
        } catch (error) {
            console.error("Error fetching country list:", error);
        }
    };

    const handleStartYearChange = (date: Dayjs | null) => {
        setStartYear(date);
        if (!date) {
            setEndYear(null);
        }
    };

    const handleEndYearChange = (date: Dayjs | null) => {
        setEndYear(date);
        if (startYear && date) {
            const newRange = `${startYear.year()}-${date.year()}`;
            setYearRanges([...yearRanges, newRange]);
            setStartYear(null);
            setEndYear(null);
        }
    };

    const handleRemoveYearRange = (range: string) => {
        setYearRanges(yearRanges.filter((yearRange) => yearRange !== range));
    };

    const handleYearChange = (date: Dayjs | null) => {
        if (date) {
            const newSelectedYears = [...selectedYears];
            const index = newSelectedYears.findIndex(year => year.year() === date.year());
            if (index === -1) {
                newSelectedYears.push(date);
            } else {
                newSelectedYears.splice(index, 1);
            }
            setSelectedYears(newSelectedYears);
        }
    };

    const handleRemoveYear = (yearToRemove: Dayjs) => {
        const newSelectedYears = selectedYears.filter(year => year.year() !== yearToRemove.year());
        setSelectedYears(newSelectedYears);
    };

    const handleDateChange2 = (date: Dayjs | null) => {
        setPickerValues(date);
        if (date && !selected2Dates.some(d => d.isSame(date, 'day'))) {
            setSelected2Dates([...selected2Dates, date]);
            setPickerValues(null);
        }
    };

    const handleRemoveDate2 = (e: React.MouseEvent, date: Dayjs) => {
        e.preventDefault();
        const updatedDates = selected2Dates.filter(d => !d.isSame(date, 'day'));
        setSelected2Dates(updatedDates);
        setPickerValues(null);
    };

    const handleDateChange = (date: Dayjs | null) => {
        setPickerValue(date);
        if (date && !selectedDates.some(d => d.isSame(date, 'day'))) {
            setSelectedDates([...selectedDates, date]);
            setPickerValue(null);
        }
    };

    const handleRemoveDate = (e: React.MouseEvent, date: Dayjs) => {
        e.preventDefault();
        const updatedDates = selectedDates.filter(d => !d.isSame(date, 'day'));
        setSelectedDates(updatedDates);
        setPickerValue(null);
    };

    const handleSearch = async () => {

        const formattedDob1 = selectedDates.length > 0
            ? selectedDates.map((date) => date.format("YYYY-MM-DD")).join(',')
            : '';

        const formattedDob2Dates = selected2Dates.length > 0
            ? selected2Dates.map((date) => date.format("YYYY-MM-DD"))
            : [];

        const formattedDob2Years = selectedYears.length > 0
            ? selectedYears.map((year) => year.format("YYYY"))
            : [];

        const formattedDateRanges = yearRanges.length > 0
            ? yearRanges.map((range) => {
                const [start, end] = range.split('-');
                return `${start}-${end}`;
            })
            : [];

        const formattedDob2 = [
            ...formattedDob2Dates,
            ...formattedDob2Years,
            ...formattedDateRanges
        ].join(',');

        const country1Names = searchParams.country1.map(id => {
            const country = uicountry.find(country => country.id === Number(id));
            return country ? country.name : '';
        }).filter(Boolean);

        const country2Names = searchParams.country2.map(id => {
            const country = uicountry.find(country => country.id === Number(id));
            return country ? country.name : '';
        }).filter(Boolean);

        const searchDTO: uiCountryDtoVerify = {
            id1: searchParams.id1,
            id2: searchParams.id2,
            country1: country1Names,
            country2: country2Names,
            dob1: formattedDob1,
            dob2: formattedDob2,
            name1: searchParams.name1,
            name2: searchParams.name2,
            entityType: searchParams.entityType,
        };
        try {
            const response = await country.getUISearchMultiParaRecords(searchDTO);

            // Set searchResults with the response data
            setSearchResults(response);
        } catch (error) {
            console.error("Error fetching search results:", error);

            setSearchResults([]);
        }
    }

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Header />
                <Box component="main" sx={{ flexGrow: 1, p: 3, m: 4 }}>
                    <Grid container item xs={12} spacing={2}>
                        <Grid item xs={4}>
                            <h6 className='allheading'>
                                SEARCH
                            </h6>
                        </Grid>
                        <Grid item xs={4}>
                            <h6 className='allheading'>
                                DATABASE
                            </h6>
                        </Grid>
                        <Grid item xs={4}>
                            <h6 className='allheading'>
                                RESULT
                            </h6>
                        </Grid>
                    </Grid>
                    <Card
                        style={{
                            padding: '1%',
                            boxShadow: 'rgb(0 0 0 / 28%) 0px 4px 8px',
                            width: '100%',
                        }}
                    >
                        <Grid container spacing={2}>
                            <Grid item xs={4}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Entity Type</InputLabel>
                                    <Select
                                        label="Entity Type"
                                        name="entityType"
                                        value={searchParams.entityType || ""}
                                        onChange={handleInputChange}
                                    >
                                        <MenuItem value="1">Individual Onboarding</MenuItem>
                                        <MenuItem value="2">Entity Onboarding</MenuItem>
                                        <MenuItem value="3">Individual Remittance</MenuItem>
                                        <MenuItem value="4">Entity Remittance</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid container item xs={12} spacing={2}>

                                <Grid item xs={4}>
                                    <TextField
                                        label="Name1"
                                        name="name1"
                                        type="text"
                                        value={searchParams.name1}
                                        onChange={handleInputChange}
                                        fullWidth
                                        size="small"
                                    />
                                </Grid>
                                <Grid item xs={4}>
                                    <TextField
                                        label="Name2 "
                                        name="name2"
                                        type="text"
                                        value={searchParams.name2}
                                        onChange={handleInputChange}
                                        fullWidth
                                        size="small"
                                    />
                                </Grid>
                                {/* <Grid item xs={4}>
                                    Name Match:{searchResults[0] ?? "N/A"}
                                </Grid> */}
                            </Grid>
                            {/* Country Dropdowns */}
                            <Grid container item xs={12} spacing={2}>
                                <Grid item xs={4}>
                                    <FormControl fullWidth size="small">
                                        <InputLabel>Country1</InputLabel>
                                        <Select
                                            label="Country"
                                            name="country1"
                                            multiple
                                            value={searchParams.country1 || []}
                                            onChange={(event) => {
                                                const value = event.target.value;
                                                setSearchParams((prev) => ({
                                                    ...prev,
                                                    country1: typeof value === 'string' ? value.split(',') : value,
                                                }));
                                            }}
                                            renderValue={(selected) =>
                                                Array.isArray(selected)
                                                    ? selected
                                                        .map((id) => {
                                                            const country = uicountry.find((country) => country.id === Number(id));
                                                            return country ? country.name : '';
                                                        })
                                                        .join(', ')
                                                    : ''
                                            }
                                        >
                                            {uicountry.map((country) => (
                                                <MenuItem key={country.id} value={String(country.id)}>
                                                    <Checkbox
                                                        checked={searchParams.country1?.includes(String(country.id)) || false}
                                                    />
                                                    <span className="check">{country.name}</span>
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={4}>
                                    <FormControl fullWidth size="small">
                                        <InputLabel>Country2</InputLabel>
                                        <Select
                                            label="Country2"
                                            name="country2"
                                            multiple
                                            value={searchParams.country2 || []}
                                            onChange={(event) => {
                                                const value = event.target.value;
                                                setSearchParams((prev) => ({
                                                    ...prev,
                                                    country2: typeof value === 'string' ? value.split(',') : value,
                                                }));
                                            }}
                                            renderValue={(selected) =>
                                                Array.isArray(selected)
                                                    ? selected
                                                        .map((id) => {
                                                            const country = uicountry.find((country) => country.id === Number(id));
                                                            return country ? country.name : '';
                                                        })
                                                        .join(', ')
                                                    : ''
                                            }
                                        >
                                            {uicountry.map((country) => (
                                                <MenuItem key={country.id} value={String(country.id)}>
                                                    <Checkbox
                                                        checked={searchParams.country2?.includes(String(country.id)) || false}
                                                    />
                                                    <span className="check">{country.name}</span>
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                {/* <Grid item xs={4}>
                                    Country Match:{searchResults[0]?.[1] ?? "N/A"}
                                </Grid> */}
                            </Grid>
                            {searchParams.entityType.toString() === "1" && (
                                <Grid container item xs={12} spacing={2}>
                                    <Grid item xs={4}>
                                        <Box>
                                            <DatePicker
                                                value={pickerValue}
                                                onChange={handleDateChange}
                                                format="MM/DD/YYYY"
                                                placeholder="Select Date"
                                                style={{ marginRight: 10, width: '100%' }}
                                                disabledDate={(current) => selectedDates.some(d => d.isSame(current, 'day'))}
                                            />
                                            <div style={{ marginTop: 10, marginBottom: 10 }}>
                                                {selectedDates.map((date, index) => (
                                                    <Tag
                                                        key={index}
                                                        closable
                                                        onClose={(e) => handleRemoveDate(e, date)}
                                                    >
                                                        {date.format('MM/DD/YYYY')}
                                                    </Tag>
                                                ))}
                                            </div>
                                        </Box>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Box>
                                            <DatePicker
                                                value={pickerValues}
                                                onChange={handleDateChange2}
                                                format="MM/DD/YYYY"
                                                placeholder="Select Date"
                                                style={{ marginRight: 10, width: '100%' }}
                                                disabledDate={(current) => selected2Dates.some(d => d.isSame(current, 'day'))}
                                            />
                                            <div style={{ marginTop: 10, marginBottom: 10 }}>
                                                {selected2Dates.map((date, index) => (
                                                    <Tag
                                                        key={index}
                                                        closable
                                                        onClose={(e) => handleRemoveDate2(e, date)}
                                                    >
                                                        {date.format('MM/DD/YYYY')}
                                                    </Tag>
                                                ))}
                                            </div>
                                        </Box>
                                    </Grid>
                                    {/* <Grid item xs={4}>
                                        Date Match:{searchResults[0]?.[2] ?? "N/A"}
                                </Grid> */}
                                </Grid>
                            )}
                        </Grid>
                        {searchParams.entityType.toString() === "1" && (
                            <Grid container item xs={12} spacing={2}>
                                <Grid item xs={4}>
                                </Grid>
                                <Grid item xs={4}>
                                    <Box>
                                        <div>
                                            <DatePicker
                                                picker="year"
                                                style={{ marginRight: 10, width: '100%' }}
                                                onChange={handleYearChange}
                                                value={null}
                                            />
                                            <div style={{ marginTop: 10, width: '100%' }}>
                                                {selectedYears.map((year, index) => (
                                                    <Tag
                                                        key={index}
                                                        closable
                                                        onClose={() => handleRemoveYear(year)}
                                                    >
                                                        {year.year()}
                                                    </Tag>
                                                ))}
                                            </div>
                                        </div>
                                    </Box>
                                </Grid>
                                <Grid item xs={4}>
                                </Grid>
                                <Grid item xs={4}>
                                </Grid>
                                <Grid item xs={4} justifyContent="flex-end">
                                    <Box>
                                        <Box display="flex" justifyContent="space-between">
                                            <div style={{ marginBottom: 10 }}>
                                                <DatePicker
                                                    picker="year"
                                                    value={startYear}
                                                    style={{ marginRight: 10, width: '100%' }}
                                                    onChange={handleStartYearChange}
                                                    placeholder="Select start year"
                                                />
                                            </div>
                                            <div style={{ marginBottom: 10, }}>
                                                <DatePicker
                                                    picker="year"
                                                    value={endYear}
                                                    style={{ marginRight: 10, width: '100%' }}
                                                    onChange={handleEndYearChange}
                                                    disabled={!startYear}
                                                    placeholder="Select end year"
                                                />
                                            </div>
                                        </Box>
                                        <div style={{ marginTop: 10, marginBottom: 10 }}>
                                            {yearRanges.map((range, index) => (
                                                <Tag key={index} closable onClose={() => handleRemoveYearRange(range)}>
                                                    {range}
                                                </Tag>
                                            ))}
                                        </div>
                                    </Box>
                                </Grid>
                            </Grid>
                        )}
                        <br></br>
                        <Grid container item xs={12} spacing={2}>
                            <Grid item xs={3}>
                                <TextField
                                    label="ID"
                                    name="id1"
                                    type="text"
                                    value={searchParams.id1}
                                    onChange={handleInputChange}
                                    fullWidth
                                    size="small"
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    label="ID "
                                    name="id2"
                                    type="text"
                                    value={searchParams.id2}
                                    onChange={handleInputChange}
                                    fullWidth
                                    size="small"
                                />
                            </Grid>
                            {/* <Grid item xs={1}>
                                ID Match:{searchResults[0]?.[3] ?? "N/A"}
                            </Grid> */}

                            <Grid item xs={2}>
                                <Button variant="contained" color="primary" onClick={handleSearch}>
                                    Search
                                </Button>
                            </Grid>
                        </Grid>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1%' }}>
                            <Typography className='allHeading'>UI TESTING SEARCH RESULTS</Typography>
                            <Button
                                variant="contained"
                                onClick={exportToExcel}
                                style={{ padding: '8px 16px' }}
                            >
                                <FileDownloadIcon />
                            </Button>
                        </div>
                        <Card style={{ padding: '1%', boxShadow: 'rgb(0 0 0 / 28%) 0px 4px 8px', width: '100%' }}>
                            <TableContainer style={{ maxHeight: '400px', overflow: 'auto' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell className="center-align">Oneside</TableCell>
                                            <TableCell className="center-align">TwoSide</TableCell>
                                            <TableCell className="center-align">soundxjw</TableCell>
                                            <TableCell className="center-align">Jaro</TableCell>
                                            <TableCell className="center-align">Fazzy</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        <TableRow>
                                            <TableCell>
                                            {
                                                (() => {
                                                const values = [searchResults[8], searchResults[6], searchResults[7]];
                                                const expression = values
                                                    .map(value => `${value ?? 0}`) // Convert undefined/null to 0
                                                    .join(" + "); // Join all values, even zeros, with a plus sign
                                                const sum = values.reduce((total, value) => total + (value ?? 0), 0); // Sum values, treating null/undefined as 0
                                                return `${expression} = ${sum}`;
                                                })()
                                            }
                                            / ID : {parseFloat(searchResults[0] ?? 0).toFixed(2)}
                                            </TableCell>

                                            <TableCell>
                                            {
                                                (() => {
                                                const values = [searchResults[9], searchResults[6], searchResults[7]];
                                                const nonZeroValues = values.filter(value => value ?? 0 !== 0);
                                                const expression = values
                                                    .map((value) => (value ?? 0) !== 0 ? `${value}` : '')
                                                    .filter(val => val !== '') // Remove empty strings
                                                    .join(" + ");
                                                const sum = nonZeroValues.reduce((total, value) => total + (value ?? 0), 0);
                                                return `${expression} = ${sum}`;
                                                })()
                                            }
                                            / ID : {parseFloat(searchResults[0] ?? 0).toFixed(2)}
                                            </TableCell>

                                            <TableCell>
                                            {
                                                (() => {
                                                const values = [searchResults[10], searchResults[6], searchResults[7]];
                                                const nonZeroValues = values.filter(value => value ?? 0 !== 0);
                                                const expression = values
                                                    .map((value) => (value ?? 0) !== 0 ? `${value}` : '')
                                                    .filter(val => val !== '') // Remove empty strings
                                                    .join(" + ");
                                                const sum = nonZeroValues.reduce((total, value) => total + (value ?? 0), 0);
                                                return `${expression} = ${sum}`;
                                                })()
                                            }
                                            / ID : {parseFloat(searchResults[0] ?? 0).toFixed(2)}
                                            </TableCell>

                                            <TableCell>
                                            {
                                                (() => {
                                                const values = [searchResults[11], searchResults[6], searchResults[7]];
                                                const nonZeroValues = values.filter(value => value ?? 0 !== 0);
                                                const expression = values
                                                    .map((value) => (value ?? 0) !== 0 ? `${value}` : '')
                                                    .filter(val => val !== '') // Remove empty strings
                                                    .join(" + ");
                                                const sum = nonZeroValues.reduce((total, value) => total + (value ?? 0), 0);
                                                return `${expression} = ${sum}`;
                                                })()
                                            }
                                            / ID : {parseFloat(searchResults[0] ?? 0).toFixed(2)}
                                            </TableCell>

                                            <TableCell>
                                            {
                                                (() => {
                                                const values = [searchResults[12], searchResults[6], searchResults[7]];
                                                const nonZeroValues = values.filter(value => value ?? 0 !== 0);
                                                const expression = values
                                                    .map((value) => (value ?? 0) !== 0 ? `${value}` : '')
                                                    .filter(val => val !== '') // Remove empty strings
                                                    .join(" + ");
                                                const sum = nonZeroValues.reduce((total, value) => total + (value ?? 0), 0);
                                                return `${expression} = ${sum}`;
                                                })()
                                            }
                                            / ID : {parseFloat(searchResults[0] ?? 0).toFixed(2)}
                                            </TableCell>
                                        </TableRow>
                                        </TableBody>

                                    {/* <TableBody>
                                        <TableRow>
                                            <TableCell>
                                            
                                                {
                                                    (() => {
                                                        const values = [searchResults[8], searchResults[6], searchResults[7]];
                                                        const expression = values
                                                            .map(value => `${value}`) 
                                                            .join(" + "); // Join all values, even zeros, with a plus sign
                                                        const sum = values.reduce((total, value) => total + value, 0); // Sum all values, including zeros
                                                        return `${expression} = ${sum}`;
                                                    })()
                                                }
                                                  /  ID : {parseFloat(searchResults[0]).toFixed(2)}
                                            </TableCell>

                                           
                                            <TableCell>
                                                {
                                                    (() => {
                                                        const values = [searchResults[9], searchResults[6], searchResults[7]];
                                                        const nonZeroValues = values.filter(value => value !== 0);
                                                        const expression = values
                                                            .map((value, index) => value !== 0 ? `${value}` : '')
                                                            .filter(val => val !== '') // Remove empty strings
                                                            .join(" + ");
                                                        const sum = nonZeroValues.reduce((total, value) => total + value, 0);
                                                        return `${expression} = ${sum}`;
                                                    })()
                                                }
                                                /  ID : {parseFloat(searchResults[0]).toFixed(2)}
                                            </TableCell>

                                                <TableCell>
                                                {
                                                    (() => {
                                                        const values = [searchResults[10], searchResults[6], searchResults[7]];
                                                        const nonZeroValues = values.filter(value => value !== 0);
                                                        const expression = values
                                                            .map((value, index) => value !== 0 ? `${value}` : '')
                                                            .filter(val => val !== '') // Remove empty strings
                                                            .join(" + ");
                                                        const sum = nonZeroValues.reduce((total, value) => total + value, 0);
                                                        return `${expression} = ${sum}`;
                                                    })()
                                                }
                                                /  ID : {parseFloat(searchResults[0]).toFixed(2)}
                                            </TableCell>

                                         
                                            <TableCell>
                                                {
                                                    (() => {
                                                        const values = [searchResults[11], searchResults[6], searchResults[7]];
                                                        const nonZeroValues = values.filter(value => value !== 0);
                                                        const expression = values
                                                            .map((value, index) => value !== 0 ? `${value}` : '')
                                                            .filter(val => val !== '') // Remove empty strings
                                                            .join(" + ");
                                                        const sum = nonZeroValues.reduce((total, value) => total + value, 0);
                                                        return `${expression} = ${sum}`;
                                                    })()
                                                }
                                                /  ID : {parseFloat(searchResults[0]).toFixed(2)}
                                            </TableCell>

                                      
                                            <TableCell>
                                                {
                                                    (() => {
                                                        const values = [searchResults[12], searchResults[6], searchResults[7]];
                                                        const nonZeroValues = values.filter(value => value !== 0);
                                                        const expression = values
                                                            .map((value, index) => value !== 0 ? `${value}` : '')
                                                            .filter(val => val !== '') // Remove empty strings
                                                            .join(" + ");
                                                        const sum = nonZeroValues.reduce((total, value) => total + value, 0);
                                                        return `${expression} = ${sum}`;
                                                    })()
                                                }
                                                /  ID : {parseFloat(searchResults[0]).toFixed(2)}
                                            </TableCell>
                                        </TableRow>


                        

                                    </TableBody> */}
                                </Table>

                            </TableContainer>

                            <TableContainer style={{ maxHeight: '400px', overflow: 'auto' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Oneside</TableCell>
                                            <TableCell>TwoSide</TableCell>
                                            <TableCell>soundxjw</TableCell>
                                            <TableCell>Jaro</TableCell>
                                            <TableCell>Fazzy</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        <TableRow >
                                            <TableCell>
                                            {parseFloat(searchResults[1]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[2]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[3]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[4]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[5]).toFixed(2)}
                                            </TableCell>
                                        </TableRow>
                                    </TableBody>
                                </Table>
                            </TableContainer>

                            {/* <TableContainer style={{ maxHeight: '400px', overflow: 'auto' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>FuzzyRatio</TableCell>
                                            <TableCell>FuzzyRatioWithOutToken</TableCell>
                                            <TableCell>FuzzyWeightedRatioWithOutToken</TableCell>
                                            <TableCell>JW_withouttoken</TableCell>
                                            <TableCell>SoundexFuzzyRatio</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        <TableRow >
                                            <TableCell>
                                            {parseFloat(searchResults[13]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[14]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[15]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[16]).toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                            {parseFloat(searchResults[17]).toFixed(2)}
                                            </TableCell>
                                        </TableRow>

                                    </TableBody>
                                </Table>
                            </TableContainer> */}

                           
                        </Card>

                    </Card>
                </Box>
            </Box>
        </>

    );
};

export default MultipleDatePicker;
