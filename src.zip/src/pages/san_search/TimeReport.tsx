import React, { useState, useEffect } from 'react';
import Header from '../../layouts/header/header';
import { Box, FormControl, Grid, InputLabel, MenuItem, Select, SelectChangeEvent, Typography, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, TextField, Chip } from '@mui/material';
import { useSelector } from 'react-redux';
import levelApiService from '../../data/services/san_search/level/level-api-service';
import SearchApiService from '../../data/services/san_search/search-api-service';
import TimeReportService from '../../data/services/san_search/timeReport/timereport-api-service';

// Interfaces
interface User {
    id: number;
    userName: string;
}
interface Status {
    id: number;
    name: string;
}
interface Level {
    id: string;
    name: string;
}

export interface TimeReportData {
    searchedName: string;
    searchInsertedTime: string;
    searchInsertedSeconds: number;
    totalRelatedRecords: number;
    allHitRecordInsertedTimes: string;
    closedCaseName: string;
    caseClosedTime: string;
    caseClosedSeconds: number;
    timeToCloseSeconds: number;
    closedLevelId: number;
    escalatedCaseName: string;
    escalationTime: string;
    escalationSeconds: number;
    timeToEscalationSeconds: number;
    escalatedLevelId: number;
    rfiCaseName: string;
    rfiTime: string;
    timeToRfiSeconds: number;

}

const TimeReport: React.FC = () => {
    const userDetails = useSelector((state: any) => state.loginReducer);
    const loginDetails = userDetails.loginDetails;
    const uid = loginDetails?.id || '';
    const username = loginDetails?.username || '';
    const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
    const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);

    const [selectedLevel, setSelectedLevel] = useState<string>('');
    const [status, setStatus] = useState<Status[]>([]);
    const [user, setUser] = useState<User[]>([]);
    const [levels, setLevels] = useState<Level[]>([]);
    const [reportData, setReportData] = useState<TimeReportData[]>([]);
    const searchApi = new SearchApiService();
    const levelServices = new levelApiService();
    const timeReportApi = new TimeReportService();
    const [loading, setLoading] = useState(false);
    const [startTime, setStartTime] = useState<string>('');
    const [endTime, setEndTime] = useState<string>('');

    useEffect(() => {
        fetchStatus();
        fetchLevels();
        fetchUser();

    }, []);


    const fetchStatus = async () => {
        try {
            const status = await searchApi.getStatus();
            setStatus(status);
        } catch (error) {
            console.error("Error fetching status:", error);
        }
    };

    const fetchUser = async () => {
        try {
            const user = await searchApi.getSanUser();
            setUser(user);
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };

    const fetchLevels = async () => {
        try {
            const levels = await levelServices.getLevel();
            setLevels(levels);
        } catch (error) {
            console.error('Error fetching levels:', error);
        }
    };
    const handleUserChange = (event: SelectChangeEvent<string[]>) => {
        const value = event.target.value;
        setSelectedUsers(typeof value === 'string' ? value.split(',') : value);
    };

    const handleStatusChange = (event: SelectChangeEvent<string[]>) => {
        const value = event.target.value;
        setSelectedStatuses(typeof value === 'string' ? value.split(',') : value);
    };


    const handleLevelChange = (event: SelectChangeEvent<string>) => {
        setSelectedLevel(event.target.value);
    };


    const handleSubmit = async () => {
        setLoading(true);
        setHasSubmitted(true);
        const allDataMap = new Map<string, TimeReportData>();

        const fetchPromises = selectedUsers.flatMap(userId =>
            selectedStatuses.map(async statusId => {
                try {
                    const data: TimeReportData[] = await timeReportApi.getTimeReportData(selectedLevel, statusId, userId, startTime, endTime);
                    console.log(`Fetched for User: ${userId}, Status: ${statusId}`, data);

                    data.forEach(item => {
                        const key = item.searchedName;

                        // Get existing record if any
                        const existing = allDataMap.get(key) || {
                            searchedName: item.searchedName,
                            searchInsertedTime: item.searchInsertedTime,
                            searchInsertedSeconds: item.searchInsertedSeconds,
                            totalRelatedRecords: item.totalRelatedRecords,
                            allHitRecordInsertedTimes: item.allHitRecordInsertedTimes,
                            closedCaseName: '',
                            caseClosedTime: '',
                            caseClosedSeconds: 0,
                            timeToCloseSeconds: 0,
                            closedLevelId: 0,
                            escalatedCaseName: '',
                            escalationTime: '',
                            escalationSeconds: 0,
                            timeToEscalationSeconds: 0,
                            escalatedLevelId: 0,
                            rfiCaseName: '',
                            rfiTime: '',
                            timeToRfiSeconds: 0
                        };

                        // Merge new data into existing based on status
                        const merged = { ...existing };

                        if (statusId === '1') {
                            merged.closedCaseName = item.closedCaseName;
                            merged.caseClosedTime = item.caseClosedTime;
                            merged.caseClosedSeconds = item.caseClosedSeconds;
                            merged.timeToCloseSeconds = item.timeToCloseSeconds;
                            merged.closedLevelId = item.closedLevelId;
                        }

                        if (statusId === '2') {
                            merged.escalatedCaseName = item.escalatedCaseName;
                            merged.escalationTime = item.escalationTime;
                            merged.escalationSeconds = item.escalationSeconds;
                            merged.timeToEscalationSeconds = item.timeToEscalationSeconds;
                            merged.escalatedLevelId = item.escalatedLevelId;
                        }

                        if (statusId === '3') {
                            merged.rfiCaseName = item.rfiCaseName;
                            merged.rfiTime = item.rfiTime;
                            merged.timeToRfiSeconds = item.timeToRfiSeconds;
                        }

                        allDataMap.set(key, merged);
                    });

                } catch (error) {
                    console.error(`Error fetching data for user: ${userId}, status: ${statusId}`, error);
                }
            })
        );

        await Promise.all(fetchPromises);
        const mergedData = Array.from(allDataMap.values());

        setReportData(mergedData);
        setLoading(false);
    };
    const [hasSubmitted, setHasSubmitted] = useState(false);



    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Header />
                <Box component="main" sx={{ flexGrow: 1, p: 3, m: 4 }}>
                    <Typography className='allHeading' variant="h5" gutterBottom>
                        TIME REPORT
                    </Typography>

                    <Box component="form" noValidate autoComplete="off" sx={{ mb: 3 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={2}>
                                <FormControl fullWidth>
                                    <InputLabel>User</InputLabel>
                                    <Select
                                        label="User"
                                        multiple
                                        value={selectedUsers}
                                        onChange={handleUserChange}
                                        size="small"
                                        renderValue={(selected) =>
                                            (selected as string[])
                                                .map(id => user.find(u => u.id.toString() === id)?.userName)
                                                .join(', ')
                                        }
                                    >
                                        {user.map((user) => (
                                            <MenuItem key={user.id} value={user.id.toString()}>
                                                {user.userName}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>

                             
                                <Box mt={1} display="flex" flexWrap="wrap" gap={1}>
                                    {selectedUsers.map((id) => {
                                        const userName = user.find(u => u.id.toString() === id)?.userName;
                                        return (
                                            <Chip
                                                key={id}
                                                label={userName}
                                                onDelete={() => {
                                                    setSelectedUsers(prev => prev.filter(i => i !== id));
                                                }}
                                                size="small"
                                            />
                                        );
                                    })}
                                </Box>
                            </Grid>

                            <Grid item xs={2}>
                                <FormControl fullWidth>
                                    <InputLabel>Status</InputLabel>
                                    <Select
                                        label="Status"
                                        multiple
                                        value={selectedStatuses}
                                        onChange={handleStatusChange}
                                        size="small"
                                        renderValue={(selected) =>
                                            (selected as string[])
                                                .map(id => status.find(s => s.id.toString() === id)?.name)
                                                .join(', ')
                                        }
                                    >
                                        {status.map((s) => (
                                            <MenuItem key={s.id} value={s.id.toString()}>
                                                {s.name}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>

                                <Box mt={1} display="flex" flexWrap="wrap" gap={1}>
                                    {selectedStatuses.map((id) => {
                                        const statusName = status.find(s => s.id.toString() === id)?.name;
                                        return (
                                            <Chip
                                                key={id}
                                                label={statusName}
                                                onDelete={() => {
                                                    setSelectedStatuses(prev => prev.filter(i => i !== id));
                                                }}
                                                size="small"
                                            />
                                        );
                                    })}
                                </Box>
                            </Grid>


                            <Grid item xs={2}>
                                <FormControl fullWidth>
                                    <InputLabel>Level</InputLabel>
                                    <Select
                                        label="Level"
                                        value={selectedLevel}
                                        onChange={handleLevelChange}
                                        size="small"
                                    >
                                        {levels.map((level) => (
                                            <MenuItem key={level.id} value={level.id}>
                                                {level.name}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={2}>
                                <TextField
                                    label="Start Time"
                                    type="date"
                                    size="small"
                                    fullWidth
                                    value={startTime}
                                    onChange={(e) => setStartTime(e.target.value)}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </Grid>

                            <Grid item xs={2}>
                                <TextField
                                    label="End Time"
                                    type="date"
                                    size="small"
                                    fullWidth
                                    value={endTime}
                                    onChange={(e) => setEndTime(e.target.value)}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </Grid>

                            <Grid item xs={2} sx={{ alignItems: 'center' }}>
                                <Button variant="contained" color="primary" onClick={handleSubmit}>
                                    Submit
                                </Button>
                            </Grid>
                        </Grid>
                    </Box>
                    {loading ? (
                        <Typography>Loading...</Typography>
                    ) :
                        hasSubmitted && reportData.length > 0 && (
                            <TableContainer component={Paper}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Searched Name</TableCell>
                                            <TableCell>Search Time</TableCell>

                                            {selectedStatuses.includes('1') && (
                                                <>
                                                    <TableCell>Alert Close</TableCell>
                                                    <TableCell>Closed Time</TableCell>
                                                    <TableCell>Time Taken To Close (Sec)</TableCell>
                                                </>
                                            )}

                                            {selectedStatuses.includes('2') && (
                                                <>
                                                    <TableCell>Escalated Case</TableCell>
                                                    <TableCell>Escalation Time</TableCell>
                                                    <TableCell>Time Taken To Escalation (Sec)</TableCell>
                                                </>
                                            )}
                                            {selectedStatuses.includes('3') && (
                                                <>
                                                    <TableCell>RFI Case</TableCell>
                                                    <TableCell>RFI Time</TableCell>
                                                    <TableCell>Time Taken To RFI (Sec)</TableCell>
                                                </>
                                            )}
                                        </TableRow>
                                    </TableHead>

                                    <TableBody>
                                        {reportData.map((item, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{item.searchedName || '-'}</TableCell>
                                                <TableCell>{item.searchInsertedTime || '-'}</TableCell>

                                                {selectedStatuses.includes('1') && (
                                                    <>
                                                        <TableCell>{item.closedCaseName || '-'}</TableCell>
                                                        <TableCell>{item.caseClosedTime || '-'}</TableCell>
                                                        <TableCell>{item.timeToCloseSeconds || '-'}</TableCell>
                                                    </>
                                                )}

                                                {selectedStatuses.includes('2') && (
                                                    <>
                                                        <TableCell>{item.escalatedCaseName || '-'}</TableCell>
                                                        <TableCell>{item.escalationTime || '-'}</TableCell>
                                                        <TableCell>{item.timeToEscalationSeconds || '-'}</TableCell>
                                                    </>
                                                )}

                                                {selectedStatuses.includes('3') && (
                                                    <>
                                                        <TableCell>{item.rfiCaseName || '-'}</TableCell>
                                                        <TableCell>{item.rfiTime || '-'}</TableCell>
                                                        <TableCell>{item.timeToRfiSeconds || '-'}</TableCell>
                                                    </>
                                                )}
                                            </TableRow>
                                        ))}
                                        {/* Average Row */}
                                        <TableRow>
                                            <TableCell colSpan={selectedStatuses.includes('1') || selectedStatuses.includes('2') ? 2 : 1} sx={{ fontWeight: 'bold' }}>
                                                Average Processing Time
                                            </TableCell>

                                            {selectedStatuses.includes('1') && (
                                                <>
                                                    <TableCell colSpan={2}></TableCell>
                                                    <TableCell sx={{ fontWeight: 'bold' }}>
                                                        {(() => {
                                                            const total = reportData.reduce((sum, item) => sum + item.timeToCloseSeconds, 0);
                                                            const avg = Math.round(total / reportData.length);
                                                            const minutes = Math.floor(avg / 60);
                                                            const seconds = avg % 60;
                                                            return `${avg} sec (${minutes} min ${seconds} sec)`;
                                                        })()}
                                                    </TableCell>
                                                </>
                                            )}

                                            {selectedStatuses.includes('2') && (
                                                <>
                                                    <TableCell colSpan={2}></TableCell>
                                                    <TableCell sx={{ fontWeight: 'bold' }}>
                                                        {(() => {
                                                            const total = reportData.reduce((sum, item) => sum + item.timeToEscalationSeconds, 0);
                                                            const avg = Math.round(total / reportData.length);
                                                            const minutes = Math.floor(avg / 60);
                                                            const seconds = avg % 60;
                                                            return `${avg} sec (${minutes} min ${seconds} sec)`;
                                                        })()}
                                                    </TableCell>
                                                </>
                                            )}
                                            {selectedStatuses.includes('3') && (
                                                <>
                                                    <TableCell colSpan={2}></TableCell>
                                                    <TableCell sx={{ fontWeight: 'bold' }}>
                                                        {(() => {
                                                            const total = reportData.reduce((sum, item) => sum + item.timeToRfiSeconds, 0);
                                                            const avg = Math.round(total / reportData.length);
                                                            const minutes = Math.floor(avg / 60);
                                                            const seconds = avg % 60;
                                                            return `${avg} sec (${minutes} min ${seconds} sec)`;
                                                        })()}
                                                    </TableCell>
                                                </>
                                            )}

                                        </TableRow>
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        )
                    }
                </Box>
            </Box>
        </>
    );
};

export default TimeReport;


